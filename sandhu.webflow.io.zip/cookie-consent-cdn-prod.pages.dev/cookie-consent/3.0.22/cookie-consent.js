var e = Object.defineProperty,
    t = (t, o, n) => ((t, o, n) => o in t ? e(t, o, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : t[o] = n)(t, "symbol" != typeof o ? o + "" : o, n),
    o = (e, t, o) => new Promise(((n, i) => {
        var s = e => {
                try {
                    r(o.next(e))
                } catch (t) {
                    i(t)
                }
            },
            a = e => {
                try {
                    r(o.throw(e))
                } catch (t) {
                    i(t)
                }
            },
            r = e => e.done ? n(e.value) : Promise.resolve(e.value).then(s, a);
        r((o = o.apply(e, t)).next())
    }));
! function() {
    const e = `__flowappz-cookie-consent-${Date.now()}__`;
    if (window[e]) console.warn("⚠️ CookieConsentManager is already loaded!");
    else {
        window[e] = !0;
        class CookieConsentManager {
            constructor() {
                t(this, "cookiePopupHidePeriod", "FOREVER"), t(this, "consentStoringEndpoint", ""), t(this, "action", ""), t(this, "cookiePreferences", {
                    strictlyNecessary: !0,
                    analytics: !1,
                    personalization: !1,
                    marketing: !1
                }), t(this, "managePreferenceBtn"), t(this, "popup"), t(this, "container"), t(this, "defaultCookiesToSet", [{
                    name: "fa-consent-ad_personalization",
                    value: "false"
                }, {
                    name: "fa-consent-ad_storage",
                    value: "false"
                }, {
                    name: "fa-consent-ad_user_data",
                    value: "false"
                }, {
                    name: "fa-consent-analytics_storage",
                    value: "false"
                }, {
                    name: "fa-consent-functionality_storage",
                    value: "false"
                }, {
                    name: "fa-consent-personalization_storage",
                    value: "false"
                }, {
                    name: "fa-consent-security_storage",
                    value: "true"
                }]), t(this, "settings"), t(this, "siteId", ""), t(this, "scrollTriggerActivated", !1), t(this, "scrollDelayTimeoutId", null), t(this, "onPopupReady", (() => {
                    var e;
                    const t = null == (e = document.querySelector("html")) ? void 0 : e.getAttribute("data-wf-site");
                    this.siteId = t || "", this.makeTheCookieConsentInteractive(t);
                    document.querySelectorAll('[flowappz-cookie-command="manage-settings"]').forEach((e => {
                        e.style.display = "flex"
                    })), this.updateUiBasedOnCookiePreferences()
                })), this.managePreferenceBtn = document.querySelector('[flowappz-cookie-preferance-manage="true"]'), this.popup = document.querySelector('[flowappz-cookie-popup="true"]'), this.container = document.querySelector('[flowappz-cookie-consent-container="true"]'), this.removeHidePopupClass(), this.popup ? (this.fetchSettings(), this.showHideManageSettingsBtnByDefault("none"), this.setupTogglers(), this.setupCookieTogglers(), this.initializeGoogleTagCookieWithDefaultConfig(), this.setCookiesInitially(), window.addEventListener("DOMContentLoaded", this.initializeCookieConsentApp.bind(this))) : console.warn("Cookie consent popup not found. Cookie consent functionality disabled.")
            }
            initScrollTriggerWithDelay(e, t, o, n) {
                if (this.scrollTriggerActivated) return;
                const i = 1e3 * o,
                    s = () => {
                        let o = !1;
                        if ("percentage" === e) {
                            const e = window.scrollY || document.documentElement.scrollTop,
                                n = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, document.body.offsetHeight, document.documentElement.offsetHeight, document.body.clientHeight, document.documentElement.clientHeight),
                                i = window.innerHeight;
                            if (n > i) {
                                const s = e / (n - i) * 100;
                                !isNaN(s) && isFinite(s) && (o = s >= t)
                            }
                        } else if ("pixel" === e) {
                            o = (window.scrollY || document.documentElement.scrollTop) >= t
                        }
                        o && !this.scrollTriggerActivated && (this.scrollTriggerActivated = !0, window.removeEventListener("scroll", s), i > 0 ? (null !== this.scrollDelayTimeoutId && clearTimeout(this.scrollDelayTimeoutId), this.scrollDelayTimeoutId = window.setTimeout((() => {
                            this.scrollDelayTimeoutId = null, this.enableFreeFunctionality(n), this.onPopupReady()
                        }), i)) : this.enableFreeFunctionality(n))
                    };
                window.addEventListener("scroll", s, {
                    passive: !0
                })
            }
            hideShowRejectButtons() {
                var e;
                const t = document.querySelectorAll('[flowappz-cookie-command="reject-all"]');
                (null == (e = this.settings) ? void 0 : e.removeRejectButton) ? t.forEach((e => {
                    e.style.display = "none"
                })): t.forEach((e => {
                    e.style.display = ""
                }))
            }
            fetchSettings() {
                return o(this, null, (function*() {
                    var e;
                    try {
                        const t = null == (e = document.querySelector("html")) ? void 0 : e.getAttribute("data-wf-site");
                        if (this.siteId = t || "", !this.siteId) return void console.error("SiteId not found!");
                        const o = Intl.DateTimeFormat().resolvedOptions().timeZone,
                            n = yield fetch(`https://cookie-consent-production.up.railway.app/api/v3/cookie-consent/sites/getAllSiteServiceSettings/${t}?timezone=${o}`);
                        if (!n.ok) return void console.error("Failed to fetch data:", n.status, n.statusText);
                        const i = yield n.json();
                        this.settings = i, this.hideShowRejectButtons(), this.regionWisePopupShowing()
                    } catch (t) {
                        console.error("Error fetching settings from data attribute:", t)
                    }
                }))
            }
            regionWisePopupShowing() {
                const {
                    isPopupShowingRegion: e
                } = this.settings;
                if (!e) {
                    const e = this.container;
                    let t = {
                        strictlyNecessary: !0,
                        personalization: !0,
                        statistical: !0,
                        analytics: !0,
                        marketing: !0
                    };
                    this.popup && this.popup.classList.add("flowappz-hide-popup"), this.action = "acceptAll", this.storeCookiePreferences(t), e && (e.style.display = "none")
                }
            }
            removeHidePopupClass() {
                this.container && this.container.classList.remove("flowappz-cookie-consent-hide-popup")
            }
            setupTogglers() {
                document.querySelectorAll("[flowappz-cookie-choice]").forEach((e => {
                    const t = e.getAttribute("flowappz-cookie-choice"),
                        o = document.querySelector(`[flowappz-cookie-content="${t}"]`);
                    o && t && e.addEventListener("input", (() => {
                        o && e.checked ? o.style.display = "block" : o.style.display = "none"
                    }))
                }))
            }
            setupCookieTogglers() {
                document.querySelectorAll('[flowappz-cookie-command="preferance-toggler"]').forEach((e => {
                    e.addEventListener("click", (e => e.stopPropagation()))
                }))
            }
            initAccordion() {
                const e = Array.from(document.querySelectorAll("[data-accordion]")),
                    t = "data-active";
                e.forEach((e => {
                    Array.from(e.querySelectorAll("[data-accordion-header]")).forEach(((e, o) => {
                        e.addEventListener("click", (() => function(e) {
                            const o = e.nextElementSibling;
                            e.hasAttribute(t) ? (e.removeAttribute(t), e.setAttribute("aria-expanded", "false"), o && (o.style.maxHeight = o.scrollHeight + "px", setTimeout((() => {
                                o.style.maxHeight = "0px"
                            }), 10), o.setAttribute("aria-hidden", "true"))) : (e.setAttribute(t, ""), e.setAttribute("aria-expanded", "true"), o && (o.style.maxHeight = "0px", o.style.overflow = "hidden", requestAnimationFrame((() => {
                                o.style.maxHeight = o.scrollHeight + "px"
                            })), o.setAttribute("aria-hidden", "false")))
                        }(e))), e.setAttribute("aria-expanded", "false"), e.setAttribute("aria-controls", `accordion-content-${o}`);
                        const n = e.nextElementSibling;
                        n && (n.id = `accordion-content-${o}`, n.setAttribute("aria-hidden", "true"), n.style.overflow = "hidden", n.style.transition = "max-height 0.3s ease-in-out", n.style.maxHeight = "0px")
                    }))
                }))
            }
            getAllSettings(e) {
                return o(this, null, (function*() {
                    if (!e) return console.error("Webflow site ID not provided."), null;
                    if (!(yield n(e))) return null;
                    try {
                        const t = yield fetch(`https://cookie-consent-production.up.railway.app/api/v3/cookie-consent/sites/getAllSiteServiceSettings/${e}`);
                        if (!t.ok) return console.error("Failed to fetch data:", t.status, t.statusText), null;
                        return yield t.json()
                    } catch (t) {
                        return console.error("An error occurred while fetching settings:", t), null
                    }
                }))
            }
            initializeGoogleTagCookieWithDefaultConfig() {
                return o(this, null, (function*() {
                    var e;
                    try {
                        const t = null == (e = document.querySelector("html")) ? void 0 : e.getAttribute("data-wf-site"),
                            o = yield this.getAllSettings(t);
                        if (t && (null == o ? void 0 : o.googleTagManagerId) && (null == o ? void 0 : o.useGoogleTagManager) && (yield n(t))) {
                            const e = document.createElement("script");
                            e.async = !0, e.src = `https://www.googletagmanager.com/gtm.js?id=${null==o?void 0:o.googleTagManagerId}`, document.head.append(e)
                        }
                        if (t && (null == o ? void 0 : o.googleTagManagerId) && (null == o ? void 0 : o.useGoogleTagManager) && (yield n(t))) {
                            const e = document.createElement("script");
                            e.textContent = `\x3c!-- Google Tag Manager --\x3e\n  (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':\n  new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],\n  j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=\n  'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);\n  })(window,document,'script','dataLayer', '${null==o?void 0:o.googleTagManagerId}');\n  \x3c!-- End Google Tag Manager --\x3e`, document.head.append(e)
                        }
                        const i = document.createElement("script");
                        i.setAttribute("foo", "true"), i.textContent = "\n          // Define dataLayer and the gtag function.\n          window.dataLayer = window.dataLayer || [];\n          function gtag(){dataLayer.push(arguments);}\n          ", t && (null == o ? void 0 : o.googleTagManagerId) && (null == o ? void 0 : o.useGoogleTagManager) && (yield n(t)) && document.head.appendChild(i)
                    } catch (t) {
                        console.log("Error initializing Google tag with default state", t)
                    }
                }))
            }
            getCookie(e) {
                const t = document.cookie.split("; ");
                for (let o = 0; o < t.length; o++) {
                    const [n, i] = t[o].split("=");
                    if (n === e) return i
                }
                return null
            }
            setCookie(e, t) {
                const o = this.cookiePreferencesExpiryDate();
                document.cookie = `${e}=${t}; Path=/; Expires=${o.toUTCString()}`
            }
            cookieSetter(e) {
                e.strictlyNecessary, this.setCookie("fa-consent-security_storage", "true"), e.personalization ? (this.setCookie("fa-consent-ad_personalization", "true"), this.setCookie("fa-consent-personalization_storage", "true"), this.setCookie("fa-consent-functionality_storage", "true")) : (this.setCookie("fa-consent-ad_personalization", "false"), this.setCookie("fa-consent-personalization_storage", "false"), this.setCookie("fa-consent-functionality_storage", "false")), e.analytics || e.statistical ? this.setCookie("fa-consent-analytics_storage", "true") : this.setCookie("fa-consent-analytics_storage", "false"), e.marketing ? (this.setCookie("fa-consent-ad_storage", "true"), this.setCookie("fa-consent-ad_user_data", "true")) : (this.setCookie("fa-consent-ad_storage", "false"), this.setCookie("fa-consent-ad_user_data", "false"))
            }
            setCookiesInitially() {
                setTimeout((() => {
                    const e = this.getCookie("cookiePreferences");
                    if (e) try {
                        const t = JSON.parse(decodeURIComponent(e));
                        this.cookieSetter(t), this.updateGoogleTagCookieConfig(t), this.launchGtmEvent(t)
                    } catch (t) {
                        console.error("Failed to parse cookiePreferences:", t)
                    } else this.defaultCookiesToSet.forEach((({
                        name: e,
                        value: t
                    }) => {
                        this.setCookie(e, t)
                    }))
                }), 5e3)
            }
            updateGoogleTagCookieConfig(e) {
                return o(this, null, (function*() {
                    var t;
                    const o = null == (t = document.querySelector("html")) ? void 0 : t.getAttribute("data-wf-site");
                    try {
                        const t = {
                            ad_storage: (null == e ? void 0 : e.marketing) ? "granted" : "denied",
                            ad_user_data: (null == e ? void 0 : e.marketing) ? "granted" : "denied",
                            ad_personalization: (null == e ? void 0 : e.personalization) ? "granted" : "denied",
                            analytics_storage: (null == e ? void 0 : e.analytics) ? "granted" : "denied",
                            functionality_storage: (null == e ? void 0 : e.analytics) ? "granted" : "denied",
                            personalization_storage: (null == e ? void 0 : e.personalization) ? "granted" : "denied",
                            security_storage: (null == e ? void 0 : e.strictlyNecessary) ? "granted" : "denied"
                        };
                        o && (yield n(o)) && ("function" == typeof window.gtag ? window.gtag("consent", "update", t) : console.warn("gtag function is not defined."))
                    } catch (i) {
                        console.error("Error updating Google tag config", i)
                    }
                }))
            }
            launchGtmEvent(e) {
                return o(this, null, (function*() {
                    var t, o, i, s, a;
                    const r = null == (t = document.querySelector("html")) ? void 0 : t.getAttribute("data-wf-site");
                    r && (yield n(r)) && ((null == e ? void 0 : e.analytics) && (null == (o = null == window ? void 0 : window.dataLayer) || o.push({
                        event: "analytics-activated",
                        tagTypeBlacklist: void 0,
                        url_passthrough: !0,
                        ads_data_redaction: !0,
                        ad_personalization: "" + ((null == e ? void 0 : e.personalization) ? "granted" : "denied"),
                        ad_storage: "" + ((null == e ? void 0 : e.marketing) ? "granted" : "denied"),
                        ad_user_data: "" + ((null == e ? void 0 : e.marketing) ? "granted" : "denied"),
                        analytics_storage: "" + ((null == e ? void 0 : e.analytics) ? "granted" : "denied"),
                        functionality_storage: "" + ((null == e ? void 0 : e.personalization) ? "granted" : "denied"),
                        personalization_storage: "" + ((null == e ? void 0 : e.personalization) ? "granted" : "denied"),
                        security_storage: "" + ((null == e ? void 0 : e.strictlyNecessary) ? "granted" : "denied")
                    })), (null == e ? void 0 : e.marketing) && (null == (i = null == window ? void 0 : window.dataLayer) || i.push({
                        event: "marketing-activated",
                        tagTypeBlacklist: void 0,
                        url_passthrough: !0,
                        ads_data_redaction: !0,
                        ad_personalization: "" + ((null == e ? void 0 : e.personalization) ? "granted" : "denied"),
                        ad_storage: "" + ((null == e ? void 0 : e.marketing) ? "granted" : "denied"),
                        ad_user_data: "" + ((null == e ? void 0 : e.marketing) ? "granted" : "denied"),
                        analytics_storage: "" + ((null == e ? void 0 : e.analytics) ? "granted" : "denied"),
                        functionality_storage: "" + ((null == e ? void 0 : e.personalization) ? "granted" : "denied"),
                        personalization_storage: "" + ((null == e ? void 0 : e.personalization) ? "granted" : "denied"),
                        security_storage: "" + ((null == e ? void 0 : e.strictlyNecessary) ? "granted" : "denied")
                    })), (null == e ? void 0 : e.personalization) && (null == (s = null == window ? void 0 : window.dataLayer) || s.push({
                        event: "personalization-activated",
                        tagTypeBlacklist: void 0,
                        url_passthrough: !0,
                        ads_data_redaction: !0,
                        ad_personalization: "" + ((null == e ? void 0 : e.personalization) ? "granted" : "denied"),
                        ad_storage: "" + ((null == e ? void 0 : e.marketing) ? "granted" : "denied"),
                        ad_user_data: "" + ((null == e ? void 0 : e.marketing) ? "granted" : "denied"),
                        analytics_storage: "" + ((null == e ? void 0 : e.analytics) ? "granted" : "denied"),
                        functionality_storage: "" + ((null == e ? void 0 : e.personalization) ? "granted" : "denied"),
                        personalization_storage: "" + ((null == e ? void 0 : e.personalization) ? "granted" : "denied"),
                        security_storage: "" + ((null == e ? void 0 : e.strictlyNecessary) ? "granted" : "denied")
                    })), (null == e ? void 0 : e.strictlyNecessary) && (null == (a = null == window ? void 0 : window.dataLayer) || a.push({
                        event: "essential-activated",
                        tagTypeBlacklist: void 0,
                        url_passthrough: !0,
                        ads_data_redaction: !0,
                        ad_personalization: "" + ((null == e ? void 0 : e.personalization) ? "granted" : "denied"),
                        ad_storage: "" + ((null == e ? void 0 : e.marketing) ? "granted" : "denied"),
                        ad_user_data: "" + ((null == e ? void 0 : e.marketing) ? "granted" : "denied"),
                        analytics_storage: "" + ((null == e ? void 0 : e.analytics) ? "granted" : "denied"),
                        functionality_storage: "" + ((null == e ? void 0 : e.personalization) ? "granted" : "denied"),
                        personalization_storage: "" + ((null == e ? void 0 : e.personalization) ? "granted" : "denied"),
                        security_storage: "" + ((null == e ? void 0 : e.strictlyNecessary) ? "granted" : "denied")
                    })))
                }))
            }
            showHideManageSettingsBtnByDefault(e = "none") {
                const t = document.querySelectorAll('[flowappz-cookie-command="manage-settings"]');
                t && t.forEach((t => {
                    t.style.display = e
                }))
            }
            getCookieByName(e) {
                const t = document.cookie.split(";");
                for (let o of t)
                    if (o = o.trim(), o.startsWith(`${e}=`)) return o.substring(e.length + 1);
                return null
            }
            updateUiBasedOnCookiePreferences() {
                var e;
                const t = this.getCookieByName("cookiePreferences"),
                    o = document.querySelector('[flowappz-cookie-preferance-manage="true"]');
                if (o && (!t || (null == (e = this.settings) ? void 0 : e.hideCookieButton) ? o.style.display = "none" : o.style.display = "flex"), t) {
                    this.cookiePreferences = JSON.parse(t);
                    document.querySelectorAll("[flowappz-cookie-choice]").forEach((e => {
                        const t = e.getAttribute("flowappz-cookie-choice"),
                            o = document.querySelector(`[flowappz-cookie-content="${t}"]`);
                        if (t && t in this.cookiePreferences) {
                            e.checked = this.cookiePreferences[t], o && this.cookiePreferences[t] && e.checked ? o.style.display = "block" : !o || this.cookiePreferences[t] || e.checked || (o.style.display = "none");
                            const n = e.closest("label");
                            if (n) {
                                const e = n.querySelector(".w-checkbox-input--inputType-custom");
                                e && (this.cookiePreferences[t] ? e.classList.add("w--redirected-checked") : "necessary" !== t && e.classList.remove("w--redirected-checked"))
                            }
                        }
                    }))
                }
            }
            connectToGoogleAnalytics(e) {
                return o(this, null, (function*() {
                    try {
                        this.initializeGTWithGoogleAnalyticsCookieWithDefaultConfig();
                        const t = yield fetch(`https://cookie-consent-production.up.railway.app/api/v3/cookie-consent/sites/${e}`);
                        if (t.ok) {
                            const e = yield t.json();
                            this.loadGoogleAnalyticsScript(e.googleAnalyticsId)
                        }
                    } catch (t) {
                        console.log("Error: ", t)
                    }
                }))
            }
            getCookiePreferences(e) {
                const t = document.cookie.split("; ").find((t => t.startsWith(e + "=")));
                return t ? t.split("=")[1] : null
            }
            initializeGTWithGoogleAnalyticsCookieWithDefaultConfig() {
                try {
                    const e = document.createElement("script");
                    e.textContent = "\n              // Define dataLayer and the gtag function.\n              window.dataLayer = window.dataLayer || [];\n              function gtag(){dataLayer.push(arguments);}\n          ", document.head.appendChild(e);
                    const t = this.getCookiePreferences("cookiePreferences"),
                        o = t ? JSON.parse(decodeURIComponent(t)) : null;
                    window.gtag("consent", "default", {
                        ad_storage: (null == o ? void 0 : o.marketing) ? "granted" : "denied",
                        ad_user_data: (null == o ? void 0 : o.marketing) ? "granted" : "denied",
                        ad_personalization: (null == o ? void 0 : o.personalization) ? "granted" : "denied",
                        analytics_storage: (null == o ? void 0 : o.analytics) ? "granted" : "denied",
                        wait_for_update: o ? 0 : 2e4
                    })
                } catch (e) {
                    console.log("Error initializing Google tag with default state", e)
                }
            }
            loadGoogleAnalyticsScript(e) {
                const t = document.createElement("script");
                t.async = !0, t.src = `https://www.googletagmanager.com/gtag/js?id=${e}`, document.head.append(t);
                const o = document.createElement("script");
                o.textContent = `\n        window.dataLayer = window.dataLayer || [];\n        function gtag(){dataLayer.push(arguments);}\n        gtag('js', new Date());\n  \n        gtag('config', '${e}');\n        `, document.head.append(o)
            }
            updateGTMWithGoogleAnalyticsCookieConfig() {
                try {
                    const e = {
                        ad_storage: this.cookiePreferences.marketing ? "granted" : "denied",
                        ad_user_data: this.cookiePreferences.marketing ? "granted" : "denied",
                        ad_personalization: this.cookiePreferences.personalization ? "granted" : "denied",
                        analytics_storage: this.cookiePreferences.analytics ? "granted" : "denied"
                    };
                    window.gtag("consent", "update", e)
                } catch (e) {
                    console.log("Error updating Google tag config", e)
                }
            }
            connectToFacebookPixel() {
                return o(this, null, (function*() {
                    var e, t, o, n, i, s, a;
                    try {
                        const r = null == (e = document.querySelector("html")) ? void 0 : e.getAttribute("data-wf-site");
                        if (!r) return;
                        const l = yield fetch(`https://cookie-consent-production.up.railway.app/api/v3/cookie-consent/sites/${r}`);
                        if (!l.ok) return;
                        const c = yield l.json(), d = c.facebookPixelRequiredConsents || {}, u = null != (t = d.analytics) && t, p = null != (o = d.personalization) && o, h = null != (n = d.marketing) && n, g = null != (i = this.cookiePreferences.analytics) && i, f = null != (s = this.cookiePreferences.personalization) && s, k = null != (a = this.cookiePreferences.marketing) && a;
                        (g || !u) && (f || !p) && (k || !h) && !c.useGoogleTagManager && this.loadFacebookPixelScript(c.facebookPixelId)
                    } catch (r) {
                        console.error("Error:", r)
                    }
                }))
            }
            loadFacebookPixelScript(e) {
                const t = document.createElement("script");
                t.setAttribute("foo", "true"), t.textContent = `\x3c!-- Meta Pixel Code --\x3e\n  \n  !function(f,b,e,v,n,t,s)\n  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?\n  n.callMethod.apply(n,arguments):n.queue.push(arguments)};\n  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';\n  n.queue=[];t=b.createElement(e);t.async=!0;\n  t.src=v;s=b.getElementsByTagName(e)[0];\n  s.parentNode.insertBefore(t,s)}(window, document,'script',\n  'https://connect.facebook.net/en_US/fbevents.js');\n  fbq('init', '${e}');\n  fbq('track', 'PageView');\n  \n  \n  \n  \x3c!-- End Meta Pixel Code --\x3e`, document.head.appendChild(t)
            }
            connectToZendesk() {
                return o(this, null, (function*() {
                    var e, t, o, n, i, s, a;
                    try {
                        const r = null == (e = document.querySelector("html")) ? void 0 : e.getAttribute("data-wf-site");
                        if (!r) return;
                        const l = yield fetch(`https://cookie-consent-production.up.railway.app/api/v3/cookie-consent/sites/${r}`);
                        if (!l.ok) return;
                        const c = yield l.json(), d = c.zendeskRequiredConsents || {}, u = null != (t = d.analytics) && t, p = null != (o = d.personalization) && o, h = null != (n = d.marketing) && n, g = null != (i = this.cookiePreferences.analytics) && i, f = null != (s = this.cookiePreferences.personalization) && s, k = null != (a = this.cookiePreferences.marketing) && a;
                        (g || !u) && (f || !p) && (k || !h) && !c.useGoogleTagManager && this.loadZendeskScript(c.zendeskId)
                    } catch (r) {
                        console.error("Error:", r)
                    }
                }))
            }
            loadZendeskScript(e) {
                const t = document.createElement("script");
                t.setAttribute("foo", "true"), t.id = "ze-snippet", t.src = `https://static.zdassets.com/ekr/snippet.js?key=${e}`, document.body.appendChild(t)
            }
            connectToTikTokPixel() {
                return o(this, null, (function*() {
                    var e, t, o, n, i, s, a;
                    try {
                        const r = null == (e = document.querySelector("html")) ? void 0 : e.getAttribute("data-wf-site");
                        if (!r) return;
                        const l = yield fetch(`https://cookie-consent-production.up.railway.app/api/v3/cookie-consent/sites/${r}`);
                        if (!l.ok) return;
                        const c = yield l.json(), d = c.tikTokPixelRequiredConsents || {}, u = null != (t = d.analytics) && t, p = null != (o = d.personalization) && o, h = null != (n = d.marketing) && n, g = null != (i = this.cookiePreferences.analytics) && i, f = null != (s = this.cookiePreferences.personalization) && s, k = null != (a = this.cookiePreferences.marketing) && a;
                        (g || !u) && (f || !p) && (k || !h) && !c.useGoogleTagManager && this.loadTikTokPixelScript(c.tikTokPixelId)
                    } catch (r) {
                        console.error("Error:", r)
                    }
                }))
            }
            loadTikTokPixelScript(e) {
                const t = document.createElement("script");
                t.setAttribute("foo", "true"), t.textContent = `\x3c!-- TikTok Pixel Code Start --\x3e\n  \n  !function (w, d, t) {\n    w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie","holdConsent","revokeConsent","grantConsent"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(\n  var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var r="https://analytics.tiktok.com/i18n/pixel/events.js",o=n&&n.partner;ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=r,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};n=document.createElement("script")\n  ;n.type="text/javascript",n.async=!0,n.src=r+"?sdkid="+e+"&lib="+t;e=document.getElementsByTagName("script")[0];e.parentNode.insertBefore(n,e)};\n  \n    ttq.load('${e}');\n    ttq.page();\n  }(window, document, 'ttq');\n  \x3c!-- TikTok Pixel Code End --\x3e`, document.head.appendChild(t)
            }
            connectToLinkedInInsightTag() {
                return o(this, null, (function*() {
                    var e, t, o, n, i, s, a;
                    try {
                        const r = null == (e = document.querySelector("html")) ? void 0 : e.getAttribute("data-wf-site");
                        if (!r) return;
                        const l = yield fetch(`https://cookie-consent-production.up.railway.app/api/v3/cookie-consent/sites/${r}`);
                        if (!l.ok) return;
                        const c = yield l.json(), d = c.linkedInInsightTagRequiredConsents || {}, u = null != (t = d.analytics) && t, p = null != (o = d.personalization) && o, h = null != (n = d.marketing) && n, g = null != (i = this.cookiePreferences.analytics) && i, f = null != (s = this.cookiePreferences.personalization) && s, k = null != (a = this.cookiePreferences.marketing) && a;
                        (g || !u) && (f || !p) && (k || !h) && !c.useGoogleTagManager && this.loadLinkedInInsightTagScript(c.linkedInInsightTagId)
                    } catch (r) {
                        console.error("Error:", r)
                    }
                }))
            }
            loadLinkedInInsightTagScript(e) {
                if (!e) return void console.error("LinkedIn Insight Tag ID is missing.");
                if (document.getElementById("linkedin-insight-script")) return void console.warn("LinkedIn Insight script is already loaded.");
                const t = document.createElement("script");
                t.type = "text/javascript", t.text = `\n          window._linkedin_partner_id = "${e}";\n          window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];\n          window._linkedin_data_partner_ids.push(window._linkedin_partner_id);\n        `, document.head.appendChild(t);
                const o = document.createElement("script");
                o.type = "text/javascript", o.async = !0, o.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js", o.id = "linkedin-insight-script", document.head.appendChild(o);
                const n = document.createElement("noscript");
                n.innerHTML = `<img height="1" width="1" style="display:none;" alt=""\n          src="https://px.ads.linkedin.com/collect/?pid=${e}&fmt=gif" />`, document.body.appendChild(n)
            }
            connectToHotjar() {
                return o(this, null, (function*() {
                    var e, t, o, n, i, s, a;
                    try {
                        const r = null == (e = document.querySelector("html")) ? void 0 : e.getAttribute("data-wf-site");
                        if (!r) return;
                        const l = yield fetch(`https://cookie-consent-production.up.railway.app/api/v3/cookie-consent/sites/${r}`);
                        if (!l.ok) return;
                        const c = yield l.json(), d = c.hotjarRequiredConsents || {}, u = null != (t = d.analytics) && t, p = null != (o = d.personalization) && o, h = null != (n = d.marketing) && n, g = null != (i = this.cookiePreferences.analytics) && i, f = null != (s = this.cookiePreferences.personalization) && s, k = null != (a = this.cookiePreferences.marketing) && a;
                        (g || !u) && (f || !p) && (k || !h) && !c.useGoogleTagManager && this.loadHotjarScript(c.hotjarId)
                    } catch (r) {
                        console.error("Error:", r)
                    }
                }))
            }
            loadHotjarScript(e) {
                const t = document.createElement("script");
                t.setAttribute("foo", "true"), t.textContent = `\n        (function (c, s, q, u, a, r, e) {\n            c.hj=c.hj||function(){(c.hj.q=c.hj.q||[]).push(arguments)};\n            c._hjSettings = { hjid: a };\n            r = s.getElementsByTagName('head')[0];\n            e = s.createElement('script');\n            e.async = true;\n            e.src = q + c._hjSettings.hjid + u;\n            r.appendChild(e);\n        })(window, document, 'https://static.hj.contentsquare.net/c/csq-', '.js', ${e});\n    `, document.head.appendChild(t)
            }
            initializeCookieConsentApp() {
                return o(this, null, (function*() {
                    var e, t, o, i;
                    const s = null == (e = document.querySelector("html")) ? void 0 : e.getAttribute("data-wf-site");
                    if (this.initAccordion(), this.hideShowRejectButtons(), s && (yield n(s))) {
                        const e = yield fetch(`https://cookie-consent-production.up.railway.app/api/v3/cookie-consent/sites/${s}`);
                        if (e.ok) {
                            const t = yield e.json();
                            this.cookiePopupHidePeriod = t.cookiePopupHidePeriod || "FOREVER", this.consentStoringEndpoint = t.consentStoringEndpoint
                        }
                        yield this.fetchSettings();
                        const n = (null == (t = this.settings) ? void 0 : t.cookiePopupScrollTriggerType) || "none",
                            a = Number(null == (o = this.settings) ? void 0 : o.cookiePopupScrollTriggerValue) || 0,
                            r = Number(null == (i = this.settings) ? void 0 : i.cookiePopupDelay) || 0;
                        if ("none" !== n && "number" == typeof a && a >= 0) {
                            const e = () => {
                                this.initScrollTriggerWithDelay(n, a, r, s), window.removeEventListener("scroll", e)
                            };
                            window.addEventListener("scroll", e, {
                                passive: !0
                            })
                        } else {
                            const e = 1e3 * r;
                            e > 0 ? setTimeout((() => {
                                this.enableFreeFunctionality(s), this.onPopupReady()
                            }), e) : (this.enableFreeFunctionality(s), this.onPopupReady())
                        }
                        const l = document.querySelector('[flowappz-cookie-choice="necessary"]');
                        l && l.setAttribute("disabled", "true"), this.updateUiBasedOnCookiePreferences()
                    }
                }))
            }
            makeTheCookieConsentInteractive(e) {
                return o(this, null, (function*() {
                    try {
                        this.makeTheUIInteractive();
                        const t = yield this.getAllSettings(e);
                        !(null == t ? void 0 : t.useGoogleTagManager) && (yield n(e)) && ((null == t ? void 0 : t.googleAnalyticsId) && this.connectToGoogleAnalytics(e), (null == t ? void 0 : t.facebookPixelId) && this.connectToFacebookPixel(), (null == t ? void 0 : t.zendeskId) && this.connectToZendesk(), (null == t ? void 0 : t.tikTokPixelId) && this.connectToTikTokPixel(), (null == t ? void 0 : t.linkedInInsightTagId) && this.connectToLinkedInInsightTag(), (null == t ? void 0 : t.hotjarId) && this.connectToHotjar())
                    } catch (t) {
                        console.log("Error: ", t)
                    }
                }))
            }
            enableFreeFunctionality(e) {
                return o(this, null, (function*() {
                    if (!this.popup || !this.shouldShowCookiePopup()) return;
                    const t = yield fetch(`https://cookie-consent-production.up.railway.app/api/v3/cookie-consent/sites/${e}`), o = yield t.json();
                    if (this.popup) {
                        this.popup.classList.remove("flowappz-hide-popup"), Object.assign(this.popup.style, {
                            top: "auto",
                            right: "auto",
                            bottom: "auto",
                            left: "auto",
                            transform: "none"
                        });
                        const e = {
                            "top-right": {
                                top: "20px",
                                right: "20px"
                            },
                            "top-left": {
                                top: "20px",
                                left: "20px"
                            },
                            "top-center": {
                                top: "20px",
                                left: "50%",
                                transform: "translateX(-50%)"
                            },
                            right: {
                                top: "50%",
                                right: "20px",
                                transform: "translateY(-50%)"
                            },
                            left: {
                                top: "50%",
                                left: "20px",
                                transform: "translateY(-50%)"
                            },
                            center: {
                                top: "50%",
                                left: "50%",
                                transform: "translate(-50%, -50%)"
                            },
                            "bottom-right": {
                                bottom: "20px",
                                right: "20px"
                            },
                            "bottom-left": {
                                bottom: "20px",
                                left: "20px"
                            },
                            "bottom-center": {
                                bottom: "20px",
                                left: "50%",
                                transform: "translateX(-50%)"
                            }
                        }[o.cookiePopupShowingSide];
                        e && Object.assign(this.popup.style, e)
                    }
                    document.querySelectorAll('[flowappz-cookie-command="close-cookie-popup"]').forEach((e => {
                        e.addEventListener("click", (() => {
                            const e = document.querySelector('[flowappz-cookie-popup="true"]');
                            e && (e.style.display = "none")
                        }))
                    }));
                    const n = document.querySelector('[flowappz-cookie-command="accept-all"]');
                    n && n.addEventListener("click", (() => {
                        this.popup && this.popup.classList.add("flowappz-hide-popup"), this.action = "acceptAll", this.storeCookiePreferences({
                            strictlyNecessary: !0,
                            personalization: !0,
                            statistical: !0,
                            analytics: !0,
                            marketing: !0
                        })
                    }));
                    const i = document.querySelector('[flowappz-cookie-command="reject-all"]');
                    i && i.addEventListener("click", (() => {
                        this.popup && this.popup.classList.add("flowappz-hide-popup"), this.action = "rejectAll", this.storeCookiePreferences()
                    }))
                }))
            }
            makeTheUIInteractive() {
                !this.shouldShowCookiePopup() && this.popup && this.popup.classList.add("flowappz-hide-popup"), this.preventDefaultFormSubmit();
                document.querySelectorAll('[flowappz-cookie-command="accept-all"]').forEach((e => {
                    e.addEventListener("click", this.handleAcceptAll.bind(this))
                }));
                document.querySelectorAll('[flowappz-cookie-command="reject-all"]').forEach((e => {
                    e.type = "button", e.addEventListener("click", (e => {
                        e.preventDefault(), e.stopPropagation(), this.handleRejectAll()
                    }))
                }));
                const e = document.querySelector('[flowappz-cookie-command="accept-selected"]');
                e && e.addEventListener("click", this.handleCookieAccept.bind(this));
                const t = document.querySelector("#flowappz-cc-accept-selected");
                t && (t.type = "button", t.innerText = "Confirm My Choices", t.addEventListener("click", (e => {
                    e.preventDefault(), e.stopPropagation(), this.handleCookieAccept()
                })));
                const o = document.querySelector("#flowappz-cc-setting-rejectall");
                o && (o.type = "button", o.innerText = "Reject Cookies", o.addEventListener("click", (e => {
                    e.preventDefault(), e.stopPropagation(), this.handleRejectAll()
                })));
                const n = document.querySelector('[flowappz-cookie-settings-wrapper="true"]');
                n && (n.style.display = "none", this.managePreferenceBtn && !this.settings.hideCookieButton && (this.managePreferenceBtn.style.display = "flex"));
                document.querySelectorAll('[flowappz-cookie-command="manage-settings"]').forEach((e => {
                    e.addEventListener("click", (() => {
                        n && (n.style.display = "flex", this.managePreferenceBtn && (this.managePreferenceBtn.style.display = "none"))
                    }))
                }));
                const i = document.querySelector('[flowappz-cookie-command="close-settings"]');
                i && n && i.addEventListener("click", (() => {
                    const e = this.getCookieByName("cookiePreferences");
                    n.style.display = "none", this.managePreferenceBtn && e && !this.settings.hideCookieButton && (this.managePreferenceBtn.style.display = "flex")
                }));
                document.querySelectorAll('[flowappz-cookie-command="close-cookie-popup"]').forEach((e => {
                    e.addEventListener("click", (() => {
                        const e = document.querySelector('[flowappz-cookie-popup="true"]');
                        e && (e.style.display = "none")
                    }))
                })), this.makeCookieTogglersInteractive()
            }
            preventDefaultFormSubmit() {
                document.querySelectorAll('[flowappz-cookie-settings-wrapper="true"] [type="submit"]').forEach((e => e.removeAttribute("type")))
            }
            shouldShowCookiePopup() {
                return !document.cookie.split(";").find((e => e.includes("hidePopup")))
            }
            makeCookieTogglersInteractive() {
                document.querySelectorAll("[flowappz-cookie-choice]").forEach((e => {
                    e.addEventListener("change", (() => {
                        const t = e.getAttribute("flowappz-cookie-choice");
                        t && t in this.cookiePreferences && (this.cookiePreferences[t] = e.checked)
                    }))
                }))
            }
            cookiePreferencesExpiryDate() {
                let e = 30;
                "FOREVER" === this.cookiePopupHidePeriod ? e = 3650 : "ONE_YEAR" === this.cookiePopupHidePeriod ? e = 365 : "SIX_MONTH" === this.cookiePopupHidePeriod ? e = 180 : "THREE_MONTH" === this.cookiePopupHidePeriod && (e = 90);
                const t = new Date;
                return new Date(t.setDate(t.getDate() + e))
            }
            storeCookiePreferences(e) {
                return o(this, null, (function*() {
                    var t, o;
                    const n = this.cookiePreferencesExpiryDate();
                    if (e) {
                        if (document.cookie = `cookiePreferences=${JSON.stringify(e)}; Path=/; Expires=${n.toUTCString()}`, document.cookie = `hidePopup=true; Path=/; Expires=${n.toUTCString()}`, this.cookieSetter(e), this.updateGoogleTagCookieConfig(e), this.launchGtmEvent(e), (null == (t = this.consentStoringEndpoint) ? void 0 : t.length) > 0) try {
                            const t = {
                                    userAgent: navigator.userAgent,
                                    platform: navigator.platform,
                                    language: navigator.language
                                },
                                o = yield fetch("https://api.ipify.org?format=json").then((e => e.json())).then((e => e.ip)).catch((e => (console.error("Failed to fetch IP address:", e), "Unknown IP"))), i = yield fetch(this.consentStoringEndpoint, {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json"
                                    },
                                    body: JSON.stringify({
                                        cookiePreferences: e,
                                        expiryDate: n.toUTCString(),
                                        browserInfo: t,
                                        userIp: o,
                                        action: this.action
                                    })
                                });
                            i.ok ? console.log("Consent preferences successfully stored.") : console.error(`Failed to store consent preferences: ${i.status} - ${i.statusText}`)
                        } catch (i) {
                            console.error("Error storing consent preferences:", i)
                        }
                    } else if (document.cookie = `cookiePreferences=${JSON.stringify(this.cookiePreferences)}; Path=/; Expires=${n.toUTCString()}`, document.cookie = `hidePopup=true; Path=/; Expires=${n.toUTCString()}`, this.cookieSetter(this.cookiePreferences), this.updateGoogleTagCookieConfig(this.cookiePreferences), this.launchGtmEvent(this.cookiePreferences), (null == (o = this.consentStoringEndpoint) ? void 0 : o.length) > 0) try {
                        const e = {
                                userAgent: navigator.userAgent,
                                platform: navigator.platform,
                                language: navigator.language
                            },
                            t = yield fetch("https://api.ipify.org?format=json").then((e => e.json())).then((e => e.ip)).catch((e => (console.error("Failed to fetch IP address:", e), "Unknown IP"))), o = yield fetch(this.consentStoringEndpoint, {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify({
                                    cookiePreferences: this.cookiePreferences,
                                    expiryDate: n.toUTCString(),
                                    browserInfo: e,
                                    userIp: t,
                                    action: this.action
                                })
                            });
                        o.ok ? console.log("Consent preferences successfully stored.") : console.error(`Failed to store consent preferences: ${o.status} - ${o.statusText}`)
                    } catch (i) {
                        console.error("Error storing consent preferences:", i)
                    }
                }))
            }
            handleCookieAccept() {
                return o(this, null, (function*() {
                    var e;
                    const t = null == (e = document.querySelector("html")) ? void 0 : e.getAttribute("data-wf-site");
                    this.popup && this.popup.classList.add("flowappz-hide-popup");
                    const o = document.querySelector('[flowappz-cookie-settings-wrapper="true"]');
                    o && (o.style.display = "none", o.setAttribute("data-state", "hide"));
                    const i = yield this.getAllSettings(t);
                    this.action = "acceptPreferred", this.storeCookiePreferences(), this.updateGTMWithGoogleAnalyticsCookieConfig(), !(null == i ? void 0 : i.useGoogleTagManager) && (yield n(t)) && ((null == i ? void 0 : i.facebookPixelId) && this.connectToFacebookPixel(), (null == i ? void 0 : i.zendeskId) && this.connectToZendesk(), (null == i ? void 0 : i.tikTokPixelId) && this.connectToTikTokPixel(), (null == i ? void 0 : i.linkedInInsightTagId) && this.connectToLinkedInInsightTag(), (null == i ? void 0 : i.hotjarId) && this.connectToHotjar()), this.updateUiBasedOnCookiePreferences()
                }))
            }
            handleAcceptAll() {
                return o(this, null, (function*() {
                    var e;
                    const t = null == (e = document.querySelector("html")) ? void 0 : e.getAttribute("data-wf-site");
                    this.popup && this.popup.classList.add("flowappz-hide-popup");
                    const o = document.querySelector('[flowappz-cookie-settings-wrapper="true"]');
                    o && (o.style.display = "none", this.managePreferenceBtn && !this.settings.hideCookieButton && (this.managePreferenceBtn.style.display = "flex"));
                    for (let n in this.cookiePreferences) this.cookiePreferences[n] = !0;
                    const i = yield this.getAllSettings(t);
                    this.action = "acceptAll", this.storeCookiePreferences(), this.updateGTMWithGoogleAnalyticsCookieConfig(), !(null == i ? void 0 : i.useGoogleTagManager) && (yield n(t)) && ((null == i ? void 0 : i.facebookPixelId) && this.connectToFacebookPixel(), (null == i ? void 0 : i.zendeskId) && this.connectToZendesk(), (null == i ? void 0 : i.tikTokPixelId) && this.connectToTikTokPixel(), (null == i ? void 0 : i.linkedInInsightTagId) && this.connectToLinkedInInsightTag(), (null == i ? void 0 : i.hotjarId) && this.connectToHotjar()), this.updateUiBasedOnCookiePreferences()
                }))
            }
            handleRejectAll() {
                return o(this, null, (function*() {
                    var e;
                    const t = null == (e = document.querySelector("html")) ? void 0 : e.getAttribute("data-wf-site");
                    this.popup && this.popup.classList.add("flowappz-hide-popup");
                    const o = document.querySelector('[flowappz-cookie-settings-wrapper="true"]');
                    o && (o.style.display = "none", this.managePreferenceBtn && !this.settings.hideCookieButton && (this.managePreferenceBtn.style.display = "flex"));
                    for (let n in this.cookiePreferences) "strictlyNecessary" !== n && (this.cookiePreferences[n] = !1);
                    const i = yield this.getAllSettings(t);
                    this.action = "rejectAll", this.storeCookiePreferences(), this.updateGTMWithGoogleAnalyticsCookieConfig(), !(null == i ? void 0 : i.useGoogleTagManager) && (yield n(t)) && ((null == i ? void 0 : i.facebookPixelId) && this.connectToFacebookPixel(), (null == i ? void 0 : i.zendeskId) && this.connectToZendesk(), (null == i ? void 0 : i.tikTokPixelId) && this.connectToTikTokPixel(), (null == i ? void 0 : i.linkedInInsightTagId) && this.connectToLinkedInInsightTag(), (null == i ? void 0 : i.hotjarId) && this.connectToHotjar()), this.updateUiBasedOnCookiePreferences()
                }))
            }
        }
        document.addEventListener("DOMContentLoaded", (() => o(this, null, (function*() {
            new CookieConsentManager
        }))))
    }

    function n(e) {
        return o(this, null, (function*() {
            const t = yield fetch(`https://cache-service-production.up.railway.app/api/license?siteId=${e}&appName=cookie-consent`);
            if (t.ok) {
                return (yield t.json()).active
            }
            return !1
        }))
    }
}();
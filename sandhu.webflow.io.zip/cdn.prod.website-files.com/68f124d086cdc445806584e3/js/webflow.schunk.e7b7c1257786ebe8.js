(self.webpackChunk = self.webpackChunk || []).push([
    ["861"], {
        5469: function() {
            function e() {
                let e = Webflow.require("ix3");
                e.ready().then(() => {
                    let a = e.getInstance();
                    a && (a.register([{
                        id: "i-6e7b140f",
                        triggers: [
                            ["wf:load", {
                                speed: .75,
                                controlType: "load"
                            }]
                        ],
                        timelineIds: ["t-60eb78d3"],
                        deleted: !1
                    }, {
                        id: "i-80579116",
                        triggers: [
                            ["wf:click", {
                                    controlType: "standard",
                                    pluginConfig: {
                                        click: "each"
                                    }
                                },
                                ["wf:class", ["bottom-dropdown-button"], {
                                    relationship: "none",
                                    firstMatchOnly: !1
                                }]
                            ]
                        ],
                        timelineIds: ["t-89ef9f91"],
                        deleted: !1
                    }, {
                        id: "i-b1b79101",
                        triggers: [
                            ["wf:click", {
                                    controlType: "standard",
                                    pluginConfig: {
                                        click: "each"
                                    }
                                },
                                ["wf:class", ["close-dropdown-button"], {
                                    relationship: "none",
                                    firstMatchOnly: !1
                                }]
                            ]
                        ],
                        timelineIds: ["t-02ad1a51"],
                        deleted: !1
                    }, {
                        id: "i-f9a6e46b",
                        triggers: [
                            ["wf:load", {
                                controlType: "load"
                            }]
                        ],
                        timelineIds: ["t-077a3bfe"],
                        deleted: !1
                    }], [{
                        id: "t-60eb78d3",
                        deleted: !1,
                        actions: [{
                            id: "ta-9502127f",
                            targets: [
                                ["wf:inst", ["4bb8e958-19fa-1770-9dad-e9ebdb902a73", "4bb8e958-19fa-1770-9dad-e9ebdb902a73"], {
                                    relationship: "none",
                                    firstMatchOnly: !1
                                }]
                            ],
                            timing: {
                                duration: 1.04,
                                position: .99
                            },
                            properties: {
                                "wf:transform": {
                                    height: [null, "0%"]
                                },
                                "wf:style": {
                                    display: [null, "none"]
                                }
                            }
                        }, {
                            id: "ta-078ec840",
                            targets: [
                                ["wf:class", ["preloader"], {
                                    relationship: "none",
                                    firstMatchOnly: !1
                                }]
                            ],
                            timing: {
                                duration: 1.03,
                                position: 0
                            },
                            tt: 2,
                            properties: {
                                "wf:transform": {},
                                "wf:style": {
                                    backgroundColor: ["hsla(9.859154929577466, 90.64%, 53.92%, 1.00)", "olive"]
                                }
                            }
                        }, {
                            id: "ta-bb0ef95d",
                            targets: [
                                ["wf:class", ["preloader"], {
                                    relationship: "none",
                                    firstMatchOnly: !1
                                }]
                            ],
                            timing: {
                                duration: .18,
                                position: 1.99,
                                ease: 2
                            },
                            tt: 0,
                            properties: {
                                "wf:transform": {
                                    display: [null, "none"]
                                },
                                "wf:style": {}
                            }
                        }]
                    }, {
                        id: "t-89ef9f91",
                        deleted: !1,
                        actions: [{
                            id: "ta-f635de75",
                            targets: [
                                ["wf:class", ["full-width-dropdown-canvas"], {
                                    relationship: "none",
                                    firstMatchOnly: !1
                                }]
                            ],
                            timing: {
                                duration: .52,
                                position: 0,
                                ease: 1
                            },
                            tt: 2,
                            properties: {
                                "wf:transform": {
                                    opacity: ["50%", "100%"],
                                    y: ["-500px", "0px"],
                                    height: ["0%", "100%"]
                                },
                                "wf:style": {
                                    display: ["none", "flex"]
                                }
                            }
                        }]
                    }, {
                        id: "t-02ad1a51",
                        deleted: !1,
                        actions: [{
                            id: "ta-06b8bb93",
                            targets: [
                                ["wf:class", ["full-width-dropdown-canvas"], {
                                    relationship: "none",
                                    firstMatchOnly: !1
                                }]
                            ],
                            timing: {
                                duration: .3,
                                position: 0,
                                ease: 0
                            },
                            tt: 0,
                            properties: {
                                "wf:transform": {
                                    opacity: ["100%", "0%"],
                                    y: ["0px", "-500px"]
                                },
                                "wf:style": {
                                    display: ["flex", "none"]
                                }
                            }
                        }]
                    }, {
                        id: "t-077a3bfe",
                        deleted: !1,
                        actions: [{
                            id: "ta-8e5310fe",
                            targets: [
                                ["wf:class", ["header-top-bar"], {
                                    relationship: "none",
                                    firstMatchOnly: !1
                                }]
                            ],
                            timing: {
                                duration: .39,
                                position: 0,
                                ease: 2
                            },
                            tt: 2,
                            properties: {
                                "wf:transform": {
                                    opacity: ["0%", "100%"],
                                    yPercent: ["-100%", "0%"]
                                }
                            }
                        }]
                    }]), window.dispatchEvent(new CustomEvent("__wf_ix3_ready")), document.documentElement.classList.add("w-mod-ix3"))
                })
            }
            Webflow.require("ix2").init({
                events: {
                    e: {
                        id: "e",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "MOUSE_OVER",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-2"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "dbe18602-ee91-ff63-67da-bd2e0fc2d0e8",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "dbe18602-ee91-ff63-67da-bd2e0fc2d0e8",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x199eeb4589c
                    },
                    "e-2": {
                        id: "e-2",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "MOUSE_OUT",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-2",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-190"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "dbe18602-ee91-ff63-67da-bd2e0fc2d0e8",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "dbe18602-ee91-ff63-67da-bd2e0fc2d0e8",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x199eeb4589d
                    },
                    "e-3": {
                        id: "e-3",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|05961cb1-b97d-309f-af30-4a201f1173d7",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|05961cb1-b97d-309f-af30-4a201f1173d7",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x199f37f9aca
                    },
                    "e-12": {
                        id: "e-12",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "PAGE_FINISH",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-7",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-11"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f",
                            appliesTo: "PAGE",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f",
                            appliesTo: "PAGE",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a09222df0
                    },
                    "e-13": {
                        id: "e-13",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInTop",
                                autoStopEventId: "e-14"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|9616f1a6-9c6f-b930-c95c-2682a87f0e44",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|9616f1a6-9c6f-b930-c95c-2682a87f0e44",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "TOP",
                            effectIn: !0
                        },
                        createdOn: 0x19a092b5f7d
                    },
                    "e-15": {
                        id: "e-15",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-16"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|7c1cf323-43ca-c870-28da-6ccd289969b4",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|7c1cf323-43ca-c870-28da-6ccd289969b4",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a092bf316
                    },
                    "e-17": {
                        id: "e-17",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-18"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a092c6dc5
                    },
                    "e-19": {
                        id: "e-19",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-20"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 600,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a092cbd83
                    },
                    "e-21": {
                        id: "e-21",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-22"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|167320bf-8854-4bc8-2064-066478b0eb17",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|167320bf-8854-4bc8-2064-066478b0eb17",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 800,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a092cfa7c
                    },
                    "e-23": {
                        id: "e-23",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-24"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|332597f2-16c6-f350-cb1d-20fa998bbe0a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|332597f2-16c6-f350-cb1d-20fa998bbe0a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a09742ba8
                    },
                    "e-25": {
                        id: "e-25",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-26"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|2411bced-3880-1aae-de3f-cf9d86ee55c8",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|2411bced-3880-1aae-de3f-cf9d86ee55c8",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a097448b6
                    },
                    "e-27": {
                        id: "e-27",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-28"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|f341cf84-3026-6910-5321-c0e544f2e5ee",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|f341cf84-3026-6910-5321-c0e544f2e5ee",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 300,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a09748ca7
                    },
                    "e-29": {
                        id: "e-29",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-30"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|f341cf84-3026-6910-5321-c0e544f2e5f0",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|f341cf84-3026-6910-5321-c0e544f2e5f0",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 600,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a0974c08e
                    },
                    "e-33": {
                        id: "e-33",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-34"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|b53b0170-f5aa-6957-44ca-cbddb6eb5708",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|b53b0170-f5aa-6957-44ca-cbddb6eb5708",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a099cfcfc
                    },
                    "e-37": {
                        id: "e-37",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-38"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|a418fea8-582c-159d-29e3-09d3cef69183",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|a418fea8-582c-159d-29e3-09d3cef69183",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a099da07c
                    },
                    "e-39": {
                        id: "e-39",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-40"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|6329c90d-7f27-6e6b-b0ca-860d7da1a8e6",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|6329c90d-7f27-6e6b-b0ca-860d7da1a8e6",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a099db42b
                    },
                    "e-41": {
                        id: "e-41",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInTop",
                                autoStopEventId: "e-42"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|1fabb4d0-004e-ae6b-b05f-859df07c44bc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|1fabb4d0-004e-ae6b-b05f-859df07c44bc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "TOP",
                            effectIn: !0
                        },
                        createdOn: 0x19a099dd6c3
                    },
                    "e-43": {
                        id: "e-43",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-44"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|1fabb4d0-004e-ae6b-b05f-859df07c44be",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|1fabb4d0-004e-ae6b-b05f-859df07c44be",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a099e1553
                    },
                    "e-49": {
                        id: "e-49",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-50"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|7d14ef06-6eaa-79f0-d0ad-b6442146a7fb",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|7d14ef06-6eaa-79f0-d0ad-b6442146a7fb",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 150,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a099ee15a
                    },
                    "e-51": {
                        id: "e-51",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-52"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|391073e6-e7a5-fc8a-6963-9f3c995b81ac",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|391073e6-e7a5-fc8a-6963-9f3c995b81ac",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 300,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a099f1efb
                    },
                    "e-54": {
                        id: "e-54",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "PAGE_FINISH",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-8",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-53"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f",
                            appliesTo: "PAGE",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f",
                            appliesTo: "PAGE",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a0cdfd8b3
                    },
                    "e-58": {
                        id: "e-58",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-59"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fc00238ecaae94eba8d22d|ce2e20f9-37d1-b669-4fd5-3f0013adcfba",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fc00238ecaae94eba8d22d|ce2e20f9-37d1-b669-4fd5-3f0013adcfba",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a1862ac3f
                    },
                    "e-60": {
                        id: "e-60",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-61"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fc00238ecaae94eba8d22d|1b33b0cb-3e16-74e4-5a12-58382cf7d862",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fc00238ecaae94eba8d22d|1b33b0cb-3e16-74e4-5a12-58382cf7d862",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a1876dcdc
                    },
                    "e-63": {
                        id: "e-63",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInTop",
                                autoStopEventId: "e-64"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fc00238ecaae94eba8d22d|926647e3-9ac8-ad8e-7c4c-460d2ab50c96",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fc00238ecaae94eba8d22d|926647e3-9ac8-ad8e-7c4c-460d2ab50c96",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "TOP",
                            effectIn: !0
                        },
                        createdOn: 0x19a18877864
                    },
                    "e-65": {
                        id: "e-65",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-66"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fc00238ecaae94eba8d22d|926647e3-9ac8-ad8e-7c4c-460d2ab50c98",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fc00238ecaae94eba8d22d|926647e3-9ac8-ad8e-7c4c-460d2ab50c98",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a18877864
                    },
                    "e-67": {
                        id: "e-67",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-68"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fc00238ecaae94eba8d22d|beb37ff2-7728-6aba-f1c6-378ba1df9111",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fc00238ecaae94eba8d22d|beb37ff2-7728-6aba-f1c6-378ba1df9111",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 150,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a18932c72
                    },
                    "e-70": {
                        id: "e-70",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-71"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fc00238ecaae94eba8d22d|e4f7a265-db84-55e9-20b8-36f38aed6d7c",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fc00238ecaae94eba8d22d|e4f7a265-db84-55e9-20b8-36f38aed6d7c",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 150,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a189713e4
                    },
                    "e-77": {
                        id: "e-77",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-78"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|bd5c5c5d-aee8-b261-9889-0f7e68911720",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|bd5c5c5d-aee8-b261-9889-0f7e68911720",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a2c297eaf
                    },
                    "e-80": {
                        id: "e-80",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|45aea1e2-572f-b471-9aa5-8144a2912cd7",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|45aea1e2-572f-b471-9aa5-8144a2912cd7",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a2c33576f
                    },
                    "e-81": {
                        id: "e-81",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInTop",
                                autoStopEventId: "e-82"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|a7d3f971-b156-6a1c-0265-7bbb29d5b012",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|a7d3f971-b156-6a1c-0265-7bbb29d5b012",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "TOP",
                            effectIn: !0
                        },
                        createdOn: 0x19a2c3c2dea
                    },
                    "e-83": {
                        id: "e-83",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-84"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|a7d3f971-b156-6a1c-0265-7bbb29d5b014",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|a7d3f971-b156-6a1c-0265-7bbb29d5b014",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a2c3c2dea
                    },
                    "e-87": {
                        id: "e-87",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInTop",
                                autoStopEventId: "e-88"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|6cd3e598-13c9-e002-8e09-ba57b7d0371d",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|6cd3e598-13c9-e002-8e09-ba57b7d0371d",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "TOP",
                            effectIn: !0
                        },
                        createdOn: 0x19a2cf853c0
                    },
                    "e-89": {
                        id: "e-89",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-90"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|6cd3e598-13c9-e002-8e09-ba57b7d0371f",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|6cd3e598-13c9-e002-8e09-ba57b7d0371f",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a2cf853c0
                    },
                    "e-91": {
                        id: "e-91",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-92"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|3aa4795f-0efb-9b35-5a03-abe425676cb5",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|3aa4795f-0efb-9b35-5a03-abe425676cb5",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a2cf995b8
                    },
                    "e-93": {
                        id: "e-93",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-94"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|4c029f53-fe91-bd1f-5386-50e4a5bdff7d",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|4c029f53-fe91-bd1f-5386-50e4a5bdff7d",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a2cfa2592
                    },
                    "e-95": {
                        id: "e-95",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInTop",
                                autoStopEventId: "e-96"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|4c029f53-fe91-bd1f-5386-50e4a5bdff7e",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|4c029f53-fe91-bd1f-5386-50e4a5bdff7e",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "TOP",
                            effectIn: !0
                        },
                        createdOn: 0x19a2cfa2592
                    },
                    "e-97": {
                        id: "e-97",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-98"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|4c029f53-fe91-bd1f-5386-50e4a5bdff80",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|4c029f53-fe91-bd1f-5386-50e4a5bdff80",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a2cfa2592
                    },
                    "e-99": {
                        id: "e-99",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-100"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|38fc0b5a-a046-dee7-fa7a-c695fb646e78",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|38fc0b5a-a046-dee7-fa7a-c695fb646e78",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a2cfa2e82
                    },
                    "e-101": {
                        id: "e-101",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInTop",
                                autoStopEventId: "e-102"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|38fc0b5a-a046-dee7-fa7a-c695fb646e79",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|38fc0b5a-a046-dee7-fa7a-c695fb646e79",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "TOP",
                            effectIn: !0
                        },
                        createdOn: 0x19a2cfa2e82
                    },
                    "e-103": {
                        id: "e-103",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-104"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|38fc0b5a-a046-dee7-fa7a-c695fb646e7b",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|38fc0b5a-a046-dee7-fa7a-c695fb646e7b",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a2cfa2e82
                    },
                    "e-107": {
                        id: "e-107",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInTop",
                                autoStopEventId: "e-108"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|d8b95f0a-74b8-3f28-d337-aa9fcaab49a2",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|d8b95f0a-74b8-3f28-d337-aa9fcaab49a2",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "TOP",
                            effectIn: !0
                        },
                        createdOn: 0x19a2d02ef42
                    },
                    "e-109": {
                        id: "e-109",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-110"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|d8b95f0a-74b8-3f28-d337-aa9fcaab49a4",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|d8b95f0a-74b8-3f28-d337-aa9fcaab49a4",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a2d02ef42
                    },
                    "e-111": {
                        id: "e-111",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-112"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|7e17210f-7d6e-89b5-88ce-152a5697c995",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|7e17210f-7d6e-89b5-88ce-152a5697c995",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a2d1adb23
                    },
                    "e-114": {
                        id: "e-114",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-115"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "690272bbe746c1c0fe21106b|152b212e-fd3b-aac0-4615-98c88ffb0de4",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "690272bbe746c1c0fe21106b|152b212e-fd3b-aac0-4615-98c88ffb0de4",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 150,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a32208d92
                    },
                    "e-118": {
                        id: "e-118",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-119"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "690272bbe746c1c0fe21106b|0980791b-8669-6eb4-f8a7-a91fc390d666",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "690272bbe746c1c0fe21106b|0980791b-8669-6eb4-f8a7-a91fc390d666",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a3236c8f3
                    },
                    "e-121": {
                        id: "e-121",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "MOUSE_CLICK",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-9",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-122"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".faq-question",
                            originalId: "ccfd05b4-8c1a-3943-574e-2719161524db",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".faq-question",
                            originalId: "ccfd05b4-8c1a-3943-574e-2719161524db",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x181fd0785f2
                    },
                    "e-122": {
                        id: "e-122",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "MOUSE_SECOND_CLICK",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-10",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-121"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".faq-question",
                            originalId: "ccfd05b4-8c1a-3943-574e-2719161524db",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".faq-question",
                            originalId: "ccfd05b4-8c1a-3943-574e-2719161524db",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x181fd0785f7
                    },
                    "e-123": {
                        id: "e-123",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "MOUSE_CLICK",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-9",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-124"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".faq-question",
                            originalId: "6315959e737d57448ecf0bfb|282f81a1-557a-1f3d-aa2b-6f5ffdf3c605",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".faq-question",
                            originalId: "6315959e737d57448ecf0bfb|282f81a1-557a-1f3d-aa2b-6f5ffdf3c605",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x182168725a6
                    },
                    "e-124": {
                        id: "e-124",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "MOUSE_SECOND_CLICK",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-10",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-123"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".faq-question",
                            originalId: "6315959e737d57448ecf0bfb|282f81a1-557a-1f3d-aa2b-6f5ffdf3c605",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".faq-question",
                            originalId: "6315959e737d57448ecf0bfb|282f81a1-557a-1f3d-aa2b-6f5ffdf3c605",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x182168725a6
                    },
                    "e-125": {
                        id: "e-125",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-126"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69029e01fdf6f1f07211a301|c3aa01ed-e19f-0b6a-325a-25b14df80c24",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69029e01fdf6f1f07211a301|c3aa01ed-e19f-0b6a-325a-25b14df80c24",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a3283a4d4
                    },
                    "e-127": {
                        id: "e-127",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-128"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|ca3af926-37e9-51cd-401b-aa95724a0ebf",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|ca3af926-37e9-51cd-401b-aa95724a0ebf",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a4b3d9dd0
                    },
                    "e-129": {
                        id: "e-129",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInTop",
                                autoStopEventId: "e-130"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|f808e609-f24a-3d32-666b-71877be274b1",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|f808e609-f24a-3d32-666b-71877be274b1",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "TOP",
                            effectIn: !0
                        },
                        createdOn: 0x19a4c0b5b9b
                    },
                    "e-131": {
                        id: "e-131",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-132"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|f808e609-f24a-3d32-666b-71877be274b3",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|f808e609-f24a-3d32-666b-71877be274b3",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 200,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a4c0b5b9b
                    },
                    "e-133": {
                        id: "e-133",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-134"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|b0fe8553-58a6-6675-dc3e-c224235bdd7e",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|b0fe8553-58a6-6675-dc3e-c224235bdd7e",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 600,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a4c18c65e
                    },
                    "e-139": {
                        id: "e-139",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInLeft",
                                autoStopEventId: "e-140"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".pricing-panel-left-packages",
                            originalId: "68f9126bb76c4ba3b6ce6af9|efdc4d5f-f1b3-b42a-2559-f79237ac1079",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".pricing-panel-left-packages",
                            originalId: "68f9126bb76c4ba3b6ce6af9|efdc4d5f-f1b3-b42a-2559-f79237ac1079",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "LEFT",
                            effectIn: !0
                        },
                        createdOn: 0x19a50da6912
                    },
                    "e-143": {
                        id: "e-143",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-144"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".flex-right.right-sde",
                            originalId: "68f9126bb76c4ba3b6ce6af9|efdc4d5f-f1b3-b42a-2559-f79237ac10db",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".flex-right.right-sde",
                            originalId: "68f9126bb76c4ba3b6ce6af9|efdc4d5f-f1b3-b42a-2559-f79237ac10db",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a50dffd4a
                    },
                    "e-145": {
                        id: "e-145",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-146"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f9126bb76c4ba3b6ce6af9|30473252-d329-9ffe-a803-b28149d4f585",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f9126bb76c4ba3b6ce6af9|30473252-d329-9ffe-a803-b28149d4f585",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a50e23af8
                    },
                    "e-147": {
                        id: "e-147",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-148"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".flex-right.gap-20px.center.pd-bottom-20px",
                            originalId: "68f9126bb76c4ba3b6ce6af9|087f94ca-01b2-c91b-40a7-52f24a845a35",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".flex-right.gap-20px.center.pd-bottom-20px",
                            originalId: "68f9126bb76c4ba3b6ce6af9|087f94ca-01b2-c91b-40a7-52f24a845a35",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a50e438fb
                    },
                    "e-149": {
                        id: "e-149",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-150"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".flex-right.gap-20px.pd-down-30px",
                            originalId: "68f9126bb76c4ba3b6ce6af9|a3242114-aab7-8519-ab91-771e2ac0abe1",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".flex-right.gap-20px.pd-down-30px",
                            originalId: "68f9126bb76c4ba3b6ce6af9|a3242114-aab7-8519-ab91-771e2ac0abe1",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a50e46b1f
                    },
                    "e-151": {
                        id: "e-151",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SHRINK_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "shrinkIn",
                                autoStopEventId: "e-152"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f9126bb76c4ba3b6ce6af9|a3366744-6b71-6a8f-3c67-543ed37077ee",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f9126bb76c4ba3b6ce6af9|a3366744-6b71-6a8f-3c67-543ed37077ee",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a50e4f5f1
                    },
                    "e-155": {
                        id: "e-155",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SHRINK_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "shrinkIn",
                                autoStopEventId: "e-156"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fc00238ecaae94eba8d22d|ce2e20f9-37d1-b669-4fd5-3f0013adcfbc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fc00238ecaae94eba8d22d|ce2e20f9-37d1-b669-4fd5-3f0013adcfbc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a50f13219
                    },
                    "e-157": {
                        id: "e-157",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInTop",
                                autoStopEventId: "e-158"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fc00238ecaae94eba8d22d|ce2e20f9-37d1-b669-4fd5-3f0013adcfbe",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fc00238ecaae94eba8d22d|ce2e20f9-37d1-b669-4fd5-3f0013adcfbe",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "TOP",
                            effectIn: !0
                        },
                        createdOn: 0x19a50f18a1f
                    },
                    "e-159": {
                        id: "e-159",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-160"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fc00238ecaae94eba8d22d|61dd6291-f929-6bc9-860a-3e88b61b4d9f",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fc00238ecaae94eba8d22d|61dd6291-f929-6bc9-860a-3e88b61b4d9f",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a50f1f170
                    },
                    "e-161": {
                        id: "e-161",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-162"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fc00238ecaae94eba8d22d|ce2e20f9-37d1-b669-4fd5-3f0013adcfc4",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fc00238ecaae94eba8d22d|ce2e20f9-37d1-b669-4fd5-3f0013adcfc4",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a50f20afe
                    },
                    "e-163": {
                        id: "e-163",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SHRINK_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "shrinkIn",
                                autoStopEventId: "e-164"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".bottom-bar-left-column",
                            originalId: "68fc00238ecaae94eba8d22d|9687c6a0-ed6a-0c6a-e24a-adb3e7f9b3bc",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".bottom-bar-left-column",
                            originalId: "68fc00238ecaae94eba8d22d|9687c6a0-ed6a-0c6a-e24a-adb3e7f9b3bc",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 400,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a50f2301e
                    },
                    "e-165": {
                        id: "e-165",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-14",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|89666fbd-e95c-1497-0dd4-9bcecb1a705e",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|89666fbd-e95c-1497-0dd4-9bcecb1a705e",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-14-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a50f47b5d
                    },
                    "e-166": {
                        id: "e-166",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInTop",
                                autoStopEventId: "e-167"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69029e01fdf6f1f07211a301|231c465d-acfd-a1e4-277a-9219e311af52",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69029e01fdf6f1f07211a301|231c465d-acfd-a1e4-277a-9219e311af52",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "TOP",
                            effectIn: !0
                        },
                        createdOn: 0x19a510c03c8
                    },
                    "e-168": {
                        id: "e-168",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-169"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69029e01fdf6f1f07211a301|7e5766bf-88af-726f-ee25-ba18a46e8853",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69029e01fdf6f1f07211a301|7e5766bf-88af-726f-ee25-ba18a46e8853",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a510c30da
                    },
                    "e-170": {
                        id: "e-170",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SHRINK_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "shrinkIn",
                                autoStopEventId: "e-171"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69029e01fdf6f1f07211a301|11cd7c66-cfe6-4019-1ab3-2dd69865b862",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69029e01fdf6f1f07211a301|11cd7c66-cfe6-4019-1ab3-2dd69865b862",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a510c4ba0
                    },
                    "e-172": {
                        id: "e-172",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-173"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69029e01fdf6f1f07211a301|11cd7c66-cfe6-4019-1ab3-2dd69865b864",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69029e01fdf6f1f07211a301|11cd7c66-cfe6-4019-1ab3-2dd69865b864",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a510c9b49
                    },
                    "e-174": {
                        id: "e-174",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-175"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".lottie-250px._50px-mg",
                            originalId: "69029e01fdf6f1f07211a301|cbd4ccca-cc0d-e335-1da1-b2d7b001a080",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".lottie-250px._50px-mg",
                            originalId: "69029e01fdf6f1f07211a301|cbd4ccca-cc0d-e335-1da1-b2d7b001a080",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a510d4b90
                    },
                    "e-176": {
                        id: "e-176",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SHRINK_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "shrinkIn",
                                autoStopEventId: "e-177"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".faq-item",
                            originalId: "69029e01fdf6f1f07211a301|d797e474-d8ef-350f-5c1e-132736d8a4f4",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".faq-item",
                            originalId: "69029e01fdf6f1f07211a301|d797e474-d8ef-350f-5c1e-132736d8a4f4",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a510e8260
                    },
                    "e-178": {
                        id: "e-178",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SHRINK_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "shrinkIn",
                                autoStopEventId: "e-179"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "5f5c3c11-8290-5e22-34ef-e921d7706576",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "5f5c3c11-8290-5e22-34ef-e921d7706576",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a511c1a98
                    },
                    "e-180": {
                        id: "e-180",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-181"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "7e3bd107-b9f5-893c-4193-4cf2ed39c1c3",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "7e3bd107-b9f5-893c-4193-4cf2ed39c1c3",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a511db290
                    },
                    "e-182": {
                        id: "e-182",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-183"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".testimonials-slides",
                            originalId: "68f124d186cdc4458065856f|0d3ec431-dbf3-744a-0458-ce71be6fd87e",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".testimonials-slides",
                            originalId: "68f124d186cdc4458065856f|0d3ec431-dbf3-744a-0458-ce71be6fd87e",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a5144fadf
                    },
                    "e-184": {
                        id: "e-184",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-185"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|0d3ec431-dbf3-744a-0458-ce71be6fd884",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|0d3ec431-dbf3-744a-0458-ce71be6fd884",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a514594be
                    },
                    "e-186": {
                        id: "e-186",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-187"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|eef1e16a-0f5a-75eb-7499-9c0f6e169b51",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|eef1e16a-0f5a-75eb-7499-9c0f6e169b51",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a5145bd15
                    },
                    "e-188": {
                        id: "e-188",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-189"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|1dd37bdc-54fa-9b9b-b7f6-5fc41d60329b",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|1dd37bdc-54fa-9b9b-b7f6-5fc41d60329b",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 400,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a5147cc2f
                    },
                    "e-190": {
                        id: "e-190",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-16",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-191"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69024379e409e4655b186c43|a6ba2d9b-53b6-d9ea-7ad2-508195e0425f",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69024379e409e4655b186c43|a6ba2d9b-53b6-d9ea-7ad2-508195e0425f",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a557f5810
                    },
                    "e-192": {
                        id: "e-192",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "PAGE_START",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-17",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-193"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69024379e409e4655b186c43",
                            appliesTo: "PAGE",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69024379e409e4655b186c43",
                            appliesTo: "PAGE",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !0,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a55846245
                    },
                    "e-194": {
                        id: "e-194",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-195"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f9126bb76c4ba3b6ce6af9|4e789bd3-6912-edef-e5f8-4a5b03a6ec39",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f9126bb76c4ba3b6ce6af9|4e789bd3-6912-edef-e5f8-4a5b03a6ec39",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a5621ae0e
                    },
                    "e-196": {
                        id: "e-196",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInRight",
                                autoStopEventId: "e-197"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f9126bb76c4ba3b6ce6af9|4e789bd3-6912-edef-e5f8-4a5b03a6ecb3",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f9126bb76c4ba3b6ce6af9|4e789bd3-6912-edef-e5f8-4a5b03a6ecb3",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "RIGHT",
                            effectIn: !0
                        },
                        createdOn: 0x19a5621ae0e
                    },
                    "e-198": {
                        id: "e-198",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-199"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fa6cabd5e6b0ab21c145f4|04511357-f429-6f74-48c8-f66675b19c48",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fa6cabd5e6b0ab21c145f4|04511357-f429-6f74-48c8-f66675b19c48",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a56e80706
                    },
                    "e-200": {
                        id: "e-200",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInRight",
                                autoStopEventId: "e-201"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fa6cabd5e6b0ab21c145f4|04511357-f429-6f74-48c8-f66675b19cc8",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fa6cabd5e6b0ab21c145f4|04511357-f429-6f74-48c8-f66675b19cc8",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "RIGHT",
                            effectIn: !0
                        },
                        createdOn: 0x19a56e80706
                    },
                    "e-202": {
                        id: "e-202",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-203"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fa6cabd5e6b0ab21c145f4|04511357-f429-6f74-48c8-f66675b19d33",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fa6cabd5e6b0ab21c145f4|04511357-f429-6f74-48c8-f66675b19d33",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a56e80706
                    },
                    "e-204": {
                        id: "e-204",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-205"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fbc88d77cc8afb558415d8|31c20cb2-cf58-4076-a533-7490d10d7e25",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fbc88d77cc8afb558415d8|31c20cb2-cf58-4076-a533-7490d10d7e25",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a56e89a02
                    },
                    "e-206": {
                        id: "e-206",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInRight",
                                autoStopEventId: "e-207"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fbc88d77cc8afb558415d8|31c20cb2-cf58-4076-a533-7490d10d7ea5",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fbc88d77cc8afb558415d8|31c20cb2-cf58-4076-a533-7490d10d7ea5",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "RIGHT",
                            effectIn: !0
                        },
                        createdOn: 0x19a56e89a02
                    },
                    "e-208": {
                        id: "e-208",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-209"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fbc88d77cc8afb558415d8|31c20cb2-cf58-4076-a533-7490d10d7f10",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fbc88d77cc8afb558415d8|31c20cb2-cf58-4076-a533-7490d10d7f10",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a56e89a02
                    },
                    "e-212": {
                        id: "e-212",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-213"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".marquee-slider-button-black",
                            originalId: "6901107f347f7a80379f591e|a39ca72e-c7b9-a834-e1bf-a62ca020daa9",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".marquee-slider-button-black",
                            originalId: "6901107f347f7a80379f591e|a39ca72e-c7b9-a834-e1bf-a62ca020daa9",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a56f3f92f
                    },
                    "e-216": {
                        id: "e-216",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-217"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|fe634fc9-62ff-cda9-a5a8-2725bfbdb4e1",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|fe634fc9-62ff-cda9-a5a8-2725bfbdb4e1",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a56f76f48
                    },
                    "e-218": {
                        id: "e-218",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-219"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|e0bbfade-ecbc-1338-9a7c-cbd72912d25f",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|e0bbfade-ecbc-1338-9a7c-cbd72912d25f",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a56f7a197
                    },
                    "e-220": {
                        id: "e-220",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|a2be0c94-0667-5f6c-0554-9fae02262cd4",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|a2be0c94-0667-5f6c-0554-9fae02262cd4",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a5a6b80ae
                    },
                    "e-221": {
                        id: "e-221",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|33599258-bf33-2018-9fca-6afab2b79531",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|33599258-bf33-2018-9fca-6afab2b79531",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a5a96e9c5
                    },
                    "e-222": {
                        id: "e-222",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "MOUSE_OVER",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-18",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-223"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "c26623d9-9550-a008-4664-3b59c60aa156",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "c26623d9-9550-a008-4664-3b59c60aa156",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a5a9af248
                    },
                    "e-223": {
                        id: "e-223",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "MOUSE_OUT",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-19",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-222"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "c26623d9-9550-a008-4664-3b59c60aa156",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "c26623d9-9550-a008-4664-3b59c60aa156",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: 0,
                            direction: null,
                            effectIn: !1
                        },
                        createdOn: 0x19a5a9af24a
                    },
                    "e-230": {
                        id: "e-230",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69024379e409e4655b186c43|93168e82-dad0-60f8-1f88-bef6079c201e",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69024379e409e4655b186c43|93168e82-dad0-60f8-1f88-bef6079c201e",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a5b3fcf8f
                    },
                    "e-231": {
                        id: "e-231",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "MOUSE_OVER",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-20",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-232"
                            }
                        },
                        mediaQueries: ["main", "medium"],
                        target: {
                            id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a5b56dbfe
                    },
                    "e-232": {
                        id: "e-232",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "MOUSE_OUT",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-23",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-231"
                            }
                        },
                        mediaQueries: ["main", "medium"],
                        target: {
                            id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a5b56dc00
                    },
                    "e-233": {
                        id: "e-233",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "MOUSE_OVER",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-21",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-234"
                            }
                        },
                        mediaQueries: ["main", "medium"],
                        target: {
                            id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a5b669cdc
                    },
                    "e-234": {
                        id: "e-234",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "MOUSE_OUT",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-22",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-233"
                            }
                        },
                        mediaQueries: ["main", "medium"],
                        target: {
                            id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a5b669cde
                    },
                    "e-235": {
                        id: "e-235",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f9126bb76c4ba3b6ce6af9|b96c0d9d-e5f4-0d54-d709-5a1209ad5589",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f9126bb76c4ba3b6ce6af9|b96c0d9d-e5f4-0d54-d709-5a1209ad5589",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a5b98b7e5
                    },
                    "e-236": {
                        id: "e-236",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f9126bb76c4ba3b6ce6af9|1c2ecad6-af59-f6e7-8b91-6b15256a7279",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f9126bb76c4ba3b6ce6af9|1c2ecad6-af59-f6e7-8b91-6b15256a7279",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a5b994197
                    },
                    "e-237": {
                        id: "e-237",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fa6cabd5e6b0ab21c145f4|4db840b8-e4bc-cdea-6bd2-a4a07c51bfe5",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fa6cabd5e6b0ab21c145f4|4db840b8-e4bc-cdea-6bd2-a4a07c51bfe5",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a5b9a055f
                    },
                    "e-238": {
                        id: "e-238",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fc00238ecaae94eba8d22d|af121067-6981-88d8-be19-9a94fca582d7",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fc00238ecaae94eba8d22d|af121067-6981-88d8-be19-9a94fca582d7",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a5b9b169d
                    },
                    "e-239": {
                        id: "e-239",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fc00238ecaae94eba8d22d|5f819b50-a521-61e9-7db3-3b3a6f97d107",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fc00238ecaae94eba8d22d|5f819b50-a521-61e9-7db3-3b3a6f97d107",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a5b9d0fa8
                    },
                    "e-240": {
                        id: "e-240",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fc00238ecaae94eba8d22d|803efa07-8d03-ccab-af91-70ef2016c671",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fc00238ecaae94eba8d22d|803efa07-8d03-ccab-af91-70ef2016c671",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a5b9d3215
                    },
                    "e-241": {
                        id: "e-241",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "690272bbe746c1c0fe21106b|a4ddbb7a-00bd-53b9-9840-29a32028596e",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "690272bbe746c1c0fe21106b|a4ddbb7a-00bd-53b9-9840-29a32028596e",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a5bbbc465
                    },
                    "e-242": {
                        id: "e-242",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|3c31d926-53e1-2a18-7963-f602ee0fa847",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|3c31d926-53e1-2a18-7963-f602ee0fa847",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a5bbc27c7
                    },
                    "e-243": {
                        id: "e-243",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|fda9b1f6-5802-f94a-410d-180c0ab9f775",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|fda9b1f6-5802-f94a-410d-180c0ab9f775",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a5bbc66aa
                    },
                    "e-244": {
                        id: "e-244",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLLING_IN_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                            config: {
                                actionListId: "a-4",
                                affectedElements: {},
                                duration: 0
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|40cfd750-7d88-69d5-f128-1522743330d8",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|40cfd750-7d88-69d5-f128-1522743330d8",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: [{
                            continuousParameterGroupId: "a-4-p",
                            smoothing: 80,
                            startsEntering: !0,
                            addStartOffset: !1,
                            addOffsetValue: 50,
                            startsExiting: !1,
                            addEndOffset: !1,
                            endOffsetValue: 50
                        }],
                        createdOn: 0x19a5bbc77e1
                    },
                    "e-245": {
                        id: "e-245",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-24",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-246"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|79560ca6-948b-b19f-1d47-8dbd36d40745",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|79560ca6-948b-b19f-1d47-8dbd36d40745",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a5c0c9dee
                    },
                    "e-247": {
                        id: "e-247",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-248"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|c69d3c55-eb14-0b0f-86d8-2d59e6914b87",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|c69d3c55-eb14-0b0f-86d8-2d59e6914b87",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a5d8071e3
                    },
                    "e-249": {
                        id: "e-249",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-250"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|c69d3c55-eb14-0b0f-86d8-2d59e6914b88",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|c69d3c55-eb14-0b0f-86d8-2d59e6914b88",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a5d8071e3
                    },
                    "e-251": {
                        id: "e-251",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-252"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|219f7d92-068d-3252-da06-375c0c9ce9eb",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|219f7d92-068d-3252-da06-375c0c9ce9eb",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a5d848ec5
                    },
                    "e-253": {
                        id: "e-253",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-254"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|219f7d92-068d-3252-da06-375c0c9ce9ec",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|219f7d92-068d-3252-da06-375c0c9ce9ec",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a5d848ec5
                    },
                    "e-255": {
                        id: "e-255",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-256"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|6cd3e598-13c9-e002-8e09-ba57b7d0371c",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|6cd3e598-13c9-e002-8e09-ba57b7d0371c",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a605f88a4
                    },
                    "e-257": {
                        id: "e-257",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-258"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|38fc0b5a-a046-dee7-fa7a-c695fb646e77",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|38fc0b5a-a046-dee7-fa7a-c695fb646e77",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 300,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a605fbaba
                    },
                    "e-259": {
                        id: "e-259",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-260"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69013955b2b4f2ab0d0b5a3e|4c029f53-fe91-bd1f-5386-50e4a5bdff7c",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69013955b2b4f2ab0d0b5a3e|4c029f53-fe91-bd1f-5386-50e4a5bdff7c",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 300,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a60603077
                    },
                    "e-261": {
                        id: "e-261",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "MOUSE_OVER",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-26",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-262"
                            }
                        },
                        mediaQueries: ["main", "medium"],
                        target: {
                            id: "68f124d186cdc4458065856f|167320bf-8854-4bc8-2064-066478b0eb17",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|167320bf-8854-4bc8-2064-066478b0eb17",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a6074b5d8
                    },
                    "e-262": {
                        id: "e-262",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "MOUSE_OUT",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-27",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-261"
                            }
                        },
                        mediaQueries: ["main", "medium"],
                        target: {
                            id: "68f124d186cdc4458065856f|167320bf-8854-4bc8-2064-066478b0eb17",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|167320bf-8854-4bc8-2064-066478b0eb17",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: null,
                            scrollOffsetUnit: null,
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a6074b5d9
                    },
                    "e-263": {
                        id: "e-263",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-264"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|6b2e25f1-4600-56aa-142f-720cb59af504",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|6b2e25f1-4600-56aa-142f-720cb59af504",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 300,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6f41669a
                    },
                    "e-265": {
                        id: "e-265",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-266"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|77f7b4a0-8cf1-bcb3-5b53-9369bf7048fa",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|77f7b4a0-8cf1-bcb3-5b53-9369bf7048fa",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 500,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6f41bc5a
                    },
                    "e-269": {
                        id: "e-269",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-270"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|4a19cf2a-6440-e3cf-8dea-50ee48f0e473",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|4a19cf2a-6440-e3cf-8dea-50ee48f0e473",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fa4f627
                    },
                    "e-271": {
                        id: "e-271",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-272"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|22ec0465-27d1-e80c-20e1-cef46f66764b",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|22ec0465-27d1-e80c-20e1-cef46f66764b",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 300,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fa9d3f5
                    },
                    "e-273": {
                        id: "e-273",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInTop",
                                autoStopEventId: "e-274"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69024379e409e4655b186c43|27c91bd2-745d-6dff-e355-ef92b948a95a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69024379e409e4655b186c43|27c91bd2-745d-6dff-e355-ef92b948a95a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "TOP",
                            effectIn: !0
                        },
                        createdOn: 0x19a6fd3c795
                    },
                    "e-275": {
                        id: "e-275",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-276"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69024379e409e4655b186c43|67a9a293-2b56-8b14-9e63-10dfce74a5dc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69024379e409e4655b186c43|67a9a293-2b56-8b14-9e63-10dfce74a5dc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fd3f1d7
                    },
                    "e-277": {
                        id: "e-277",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-278"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69024379e409e4655b186c43|27c91bd2-745d-6dff-e355-ef92b948a95c",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69024379e409e4655b186c43|27c91bd2-745d-6dff-e355-ef92b948a95c",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fd4133d
                    },
                    "e-279": {
                        id: "e-279",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-280"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69024379e409e4655b186c43|ab8f2bdd-3a0a-12c8-0069-b172377e0219",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69024379e409e4655b186c43|ab8f2bdd-3a0a-12c8-0069-b172377e0219",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a6fd42ac5
                    },
                    "e-281": {
                        id: "e-281",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInTop",
                                autoStopEventId: "e-282"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69024379e409e4655b186c43|98eab405-c9fe-c001-1fb6-f7706e459869",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69024379e409e4655b186c43|98eab405-c9fe-c001-1fb6-f7706e459869",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "TOP",
                            effectIn: !0
                        },
                        createdOn: 0x19a6fd4583d
                    },
                    "e-283": {
                        id: "e-283",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-284"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "69024379e409e4655b186c43|2fabdd28-7d57-153f-2e74-4f32d734cdd6",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "69024379e409e4655b186c43|2fabdd28-7d57-153f-2e74-4f32d734cdd6",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fd485ee
                    },
                    "e-285": {
                        id: "e-285",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-286"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".flex-down.center-align.gap-10px._10px-gap",
                            originalId: "69024379e409e4655b186c43|456378d4-94e9-87d0-578b-07a0b5d7bb24",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".flex-down.center-align.gap-10px._10px-gap",
                            originalId: "69024379e409e4655b186c43|456378d4-94e9-87d0-578b-07a0b5d7bb24",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fd5275e
                    },
                    "e-287": {
                        id: "e-287",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-288"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            selector: ".flex-right.gap-20px.middle-align",
                            originalId: "6901107f347f7a80379f591e|dd2f094c-75c7-0f82-e260-ecd8b996d0d6",
                            appliesTo: "CLASS"
                        },
                        targets: [{
                            selector: ".flex-right.gap-20px.middle-align",
                            originalId: "6901107f347f7a80379f591e|dd2f094c-75c7-0f82-e260-ecd8b996d0d6",
                            appliesTo: "CLASS"
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fd9e3d7
                    },
                    "e-289": {
                        id: "e-289",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SHRINK_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "shrinkIn",
                                autoStopEventId: "e-290"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|8ca6cdff-adb5-b846-b867-98ce105d52e8",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|8ca6cdff-adb5-b846-b867-98ce105d52e8",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fda1eb3
                    },
                    "e-291": {
                        id: "e-291",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-292"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|41674609-b7a7-702c-6572-82e970f63263",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|41674609-b7a7-702c-6572-82e970f63263",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fda499e
                    },
                    "e-293": {
                        id: "e-293",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-294"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|41674609-b7a7-702c-6572-82e970f63265",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|41674609-b7a7-702c-6572-82e970f63265",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fda85d5
                    },
                    "e-295": {
                        id: "e-295",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-296"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|bfe0547a-a991-d481-f81f-9a0a9820f587",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|bfe0547a-a991-d481-f81f-9a0a9820f587",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a6fdaa0e4
                    },
                    "e-297": {
                        id: "e-297",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SHRINK_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "shrinkIn",
                                autoStopEventId: "e-298"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|e6e34d8e-c27e-5f98-1a4c-f0cb08a14cc8",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|e6e34d8e-c27e-5f98-1a4c-f0cb08a14cc8",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fdb04f6
                    },
                    "e-299": {
                        id: "e-299",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-300"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|e6e34d8e-c27e-5f98-1a4c-f0cb08a14ccb",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|e6e34d8e-c27e-5f98-1a4c-f0cb08a14ccb",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fdb293d
                    },
                    "e-301": {
                        id: "e-301",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-302"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|e6e34d8e-c27e-5f98-1a4c-f0cb08a14ccd",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|e6e34d8e-c27e-5f98-1a4c-f0cb08a14ccd",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fdb45fb
                    },
                    "e-303": {
                        id: "e-303",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-304"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|e6e34d8e-c27e-5f98-1a4c-f0cb08a14ce6",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|e6e34d8e-c27e-5f98-1a4c-f0cb08a14ce6",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a6fdb6357
                    },
                    "e-305": {
                        id: "e-305",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SHRINK_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "shrinkIn",
                                autoStopEventId: "e-306"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|daeb7725-a3b0-2a55-2a69-13daf48d2026",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|daeb7725-a3b0-2a55-2a69-13daf48d2026",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fdc91fd
                    },
                    "e-307": {
                        id: "e-307",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-308"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|daeb7725-a3b0-2a55-2a69-13daf48d2028",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|daeb7725-a3b0-2a55-2a69-13daf48d2028",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fdcae47
                    },
                    "e-309": {
                        id: "e-309",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-310"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|daeb7725-a3b0-2a55-2a69-13daf48d202a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|daeb7725-a3b0-2a55-2a69-13daf48d202a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fdcd6d7
                    },
                    "e-313": {
                        id: "e-313",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SHRINK_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "shrinkIn",
                                autoStopEventId: "e-314"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|f0c90b62-65f3-dcd7-15af-43f5fa25f4f0",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|f0c90b62-65f3-dcd7-15af-43f5fa25f4f0",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fdf860c
                    },
                    "e-315": {
                        id: "e-315",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-316"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|750f2aed-d7bc-4056-0f11-39fe7e7cabb9",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|750f2aed-d7bc-4056-0f11-39fe7e7cabb9",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fdfa1f6
                    },
                    "e-317": {
                        id: "e-317",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-318"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|750f2aed-d7bc-4056-0f11-39fe7e7cabbb",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|750f2aed-d7bc-4056-0f11-39fe7e7cabbb",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fdfbd1c
                    },
                    "e-319": {
                        id: "e-319",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-320"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|750f2aed-d7bc-4056-0f11-39fe7e7cabd4",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|750f2aed-d7bc-4056-0f11-39fe7e7cabd4",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a6fdfcfc6
                    },
                    "e-321": {
                        id: "e-321",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SHRINK_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "shrinkIn",
                                autoStopEventId: "e-322"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|11f2f9d8-91ec-67ba-5497-e2889f4b2500",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|11f2f9d8-91ec-67ba-5497-e2889f4b2500",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fe0013c
                    },
                    "e-323": {
                        id: "e-323",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-324"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|047062db-52d2-2413-bc86-be44e09b3587",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|047062db-52d2-2413-bc86-be44e09b3587",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fe03459
                    },
                    "e-325": {
                        id: "e-325",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-326"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|047062db-52d2-2413-bc86-be44e09b3589",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|047062db-52d2-2413-bc86-be44e09b3589",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fe04a5c
                    },
                    "e-327": {
                        id: "e-327",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-328"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|047062db-52d2-2413-bc86-be44e09b35a2",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|047062db-52d2-2413-bc86-be44e09b35a2",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a6fe06f2d
                    },
                    "e-329": {
                        id: "e-329",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SHRINK_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "shrinkIn",
                                autoStopEventId: "e-330"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|041402ff-98f6-a4ed-01cd-f0ae00239f5f",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|041402ff-98f6-a4ed-01cd-f0ae00239f5f",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fe0ec1d
                    },
                    "e-331": {
                        id: "e-331",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-332"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|cbe97e59-554e-d31d-6e65-9ecf244d565a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|cbe97e59-554e-d31d-6e65-9ecf244d565a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fe19792
                    },
                    "e-333": {
                        id: "e-333",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-334"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|cbe97e59-554e-d31d-6e65-9ecf244d5680",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|cbe97e59-554e-d31d-6e65-9ecf244d5680",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a6fe1b127
                    },
                    "e-335": {
                        id: "e-335",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInBottom",
                                autoStopEventId: "e-336"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|e66c0cbe-46e0-f429-449f-d78682ed7ba3",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|e66c0cbe-46e0-f429-449f-d78682ed7ba3",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "BOTTOM",
                            effectIn: !0
                        },
                        createdOn: 0x19a6fe3006f
                    },
                    "e-337": {
                        id: "e-337",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-338"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|4f2ef987-193a-e8b6-4141-f4a8cac229ae",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|4f2ef987-193a-e8b6-4141-f4a8cac229ae",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fe325cf
                    },
                    "e-339": {
                        id: "e-339",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-340"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|5d7667cb-959a-fc2f-2940-6eacb63e3316",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|5d7667cb-959a-fc2f-2940-6eacb63e3316",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fe33916
                    },
                    "e-341": {
                        id: "e-341",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInLeft",
                                autoStopEventId: "e-342"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|4e712932-c382-fd70-7901-707cebbd1735",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|4e712932-c382-fd70-7901-707cebbd1735",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "LEFT",
                            effectIn: !0
                        },
                        createdOn: 0x19a6fe3a455
                    },
                    "e-343": {
                        id: "e-343",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-344"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|bd5c5c5d-aee8-b261-9889-0f7e68911728",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|bd5c5c5d-aee8-b261-9889-0f7e68911728",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19a6fe3c486
                    },
                    "e-345": {
                        id: "e-345",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-30",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-346"
                            }
                        },
                        mediaQueries: ["small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 50,
                            scrollOffsetUnit: "%",
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a70390a75
                    },
                    "e-346": {
                        id: "e-346",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "SCROLL_OUT_OF_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-31",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-345"
                            }
                        },
                        mediaQueries: ["small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acc",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 25,
                            scrollOffsetUnit: "%",
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a70390a78
                    },
                    "e-347": {
                        id: "e-347",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-28",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-348"
                            }
                        },
                        mediaQueries: ["small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 50,
                            scrollOffsetUnit: "%",
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a703928a4
                    },
                    "e-348": {
                        id: "e-348",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "SCROLL_OUT_OF_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-29",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-347"
                            }
                        },
                        mediaQueries: ["small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 25,
                            scrollOffsetUnit: "%",
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a703928a6
                    },
                    "e-349": {
                        id: "e-349",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-32",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-350"
                            }
                        },
                        mediaQueries: ["small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|167320bf-8854-4bc8-2064-066478b0eb17",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|167320bf-8854-4bc8-2064-066478b0eb17",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 50,
                            scrollOffsetUnit: "%",
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a703f1514
                    },
                    "e-350": {
                        id: "e-350",
                        name: "",
                        animationType: "custom",
                        eventTypeId: "SCROLL_OUT_OF_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "GENERAL_START_ACTION",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 0,
                                actionListId: "a-33",
                                affectedElements: {},
                                playInReverse: !1,
                                autoStopEventId: "e-349"
                            }
                        },
                        mediaQueries: ["small", "tiny"],
                        target: {
                            id: "68f124d186cdc4458065856f|167320bf-8854-4bc8-2064-066478b0eb17",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f124d186cdc4458065856f|167320bf-8854-4bc8-2064-066478b0eb17",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 25,
                            scrollOffsetUnit: "%",
                            delay: null,
                            direction: null,
                            effectIn: null
                        },
                        createdOn: 0x19a703f1518
                    },
                    "e-351": {
                        id: "e-351",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-352"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fa6cabd5e6b0ab21c145f4|b277f20c-12cd-b3c9-d885-1dc372ec33d3",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fa6cabd5e6b0ab21c145f4|b277f20c-12cd-b3c9-d885-1dc372ec33d3",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19b28c9f1c0
                    },
                    "e-353": {
                        id: "e-353",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInRight",
                                autoStopEventId: "e-354"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68fa6cabd5e6b0ab21c145f4|b277f20c-12cd-b3c9-d885-1dc372ec3451",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68fa6cabd5e6b0ab21c145f4|b277f20c-12cd-b3c9-d885-1dc372ec3451",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "RIGHT",
                            effectIn: !0
                        },
                        createdOn: 0x19b28c9f1c0
                    },
                    "e-359": {
                        id: "e-359",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "SLIDE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "slideInRight",
                                autoStopEventId: "e-360"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "68f9126bb76c4ba3b6ce6af9|b479aa1a-83db-435f-0cb3-a799c970420a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "68f9126bb76c4ba3b6ce6af9|b479aa1a-83db-435f-0cb3-a799c970420a",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: "RIGHT",
                            effectIn: !0
                        },
                        createdOn: 0x19b4dc13d9c
                    },
                    "e-361": {
                        id: "e-361",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-362"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|73d009de-8e91-b6fd-09f4-7e5de2894777",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|73d009de-8e91-b6fd-09f4-7e5de2894777",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19b70429cc1
                    },
                    "e-363": {
                        id: "e-363",
                        name: "",
                        animationType: "preset",
                        eventTypeId: "SCROLL_INTO_VIEW",
                        action: {
                            id: "",
                            actionTypeId: "FADE_EFFECT",
                            instant: !1,
                            config: {
                                actionListId: "fadeIn",
                                autoStopEventId: "e-364"
                            }
                        },
                        mediaQueries: ["main", "medium", "small", "tiny"],
                        target: {
                            id: "6901107f347f7a80379f591e|73d009de-8e91-b6fd-09f4-7e5de2894778",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        },
                        targets: [{
                            id: "6901107f347f7a80379f591e|73d009de-8e91-b6fd-09f4-7e5de2894778",
                            appliesTo: "ELEMENT",
                            styleBlockIds: []
                        }],
                        config: {
                            loop: !1,
                            playInReverse: !1,
                            scrollOffsetValue: 0,
                            scrollOffsetUnit: "%",
                            delay: 0,
                            direction: null,
                            effectIn: !0
                        },
                        createdOn: 0x19b70429cc1
                    }
                },
                actionLists: {
                    a: {
                        id: "a",
                        title: "Drop-down-Button-Hover-in",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-n",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: !0,
                                        id: "dbe18602-ee91-ff63-67da-bd2e0fc2d0e8"
                                    },
                                    globalSwatchId: "",
                                    rValue: 244,
                                    bValue: 31,
                                    gValue: 66,
                                    aValue: 1
                                }
                            }, {
                                id: "a-n-2",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".dropdown-line",
                                        selectorGuids: ["e7964ab9-896e-c01f-9251-41a878e7ebbb"]
                                    },
                                    globalSwatchId: "",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x199eeb4654b
                    },
                    "a-2": {
                        id: "a-2",
                        title: "Drop-down-Button-Hover-out",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-2-n",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: !0,
                                        id: "dbe18602-ee91-ff63-67da-bd2e0fc2d0e8"
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-2-n-2",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".dropdown-line",
                                        selectorGuids: ["e7964ab9-896e-c01f-9251-41a878e7ebbb"]
                                    },
                                    globalSwatchId: "",
                                    rValue: 244,
                                    bValue: 31,
                                    gValue: 66,
                                    aValue: 1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x199eeb4654b
                    },
                    "a-4": {
                        id: "a-4",
                        title: "Image Marquee Slider",
                        continuousParameterGroups: [{
                            id: "a-4-p",
                            type: "SCROLL_PROGRESS",
                            parameterLabel: "Scroll",
                            continuousActionGroups: [{
                                keyframe: 0,
                                actionItems: [{
                                    id: "a-4-n",
                                    actionTypeId: "TRANSFORM_MOVE",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            selector: ".images-container-marquee",
                                            selectorGuids: ["5b0415b0-52e0-872a-c617-af58a4bed27a"]
                                        },
                                        xValue: 0,
                                        xUnit: "%",
                                        yUnit: "PX",
                                        zUnit: "PX"
                                    }
                                }]
                            }, {
                                keyframe: 100,
                                actionItems: [{
                                    id: "a-4-n-2",
                                    actionTypeId: "TRANSFORM_MOVE",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            selector: ".images-container-marquee",
                                            selectorGuids: ["5b0415b0-52e0-872a-c617-af58a4bed27a"]
                                        },
                                        xValue: -30,
                                        xUnit: "%",
                                        yUnit: "PX",
                                        zUnit: "PX"
                                    }
                                }]
                            }]
                        }],
                        createdOn: 0x199f37fac31
                    },
                    "a-7": {
                        id: "a-7",
                        title: "Banner-Animation",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-7-n",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        id: "68f124d186cdc4458065856f|f62816b4-c386-9eee-2b17-30f69cf2c757"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }, {
                                id: "a-7-n-23",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "68f124d186cdc4458065856f|05961cb1-b97d-309f-af30-4a201f1173d7"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }, {
                                id: "a-7-n-20",
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "68f124d186cdc4458065856f|726abba1-326a-32db-958f-4cbc02a2d9c8"
                                    },
                                    yValue: 50,
                                    xUnit: "PX",
                                    yUnit: "px",
                                    zUnit: "PX"
                                }
                            }, {
                                id: "a-7-n-19",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "68f124d186cdc4458065856f|726abba1-326a-32db-958f-4cbc02a2d9c8"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }, {
                                id: "a-7-n-16",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "68f124d186cdc4458065856f|726abba1-326a-32db-958f-4cbc02a2d9c6"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }, {
                                id: "a-7-n-15",
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "68f124d186cdc4458065856f|726abba1-326a-32db-958f-4cbc02a2d9c6"
                                    },
                                    yValue: 20,
                                    xUnit: "PX",
                                    yUnit: "px",
                                    zUnit: "PX"
                                }
                            }, {
                                id: "a-7-n-13",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "68f124d186cdc4458065856f|e8ca681d-e259-b96a-8672-e4177ec7f4b9"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }, {
                                id: "a-7-n-11",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "68f124d186cdc4458065856f|04fafe08-069b-504a-f2ee-60d45e2bf7b1"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }, {
                                id: "a-7-n-9",
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "68f124d186cdc4458065856f|04fafe08-069b-504a-f2ee-60d45e2bf7b1"
                                    },
                                    yValue: 65,
                                    xUnit: "PX",
                                    yUnit: "px",
                                    zUnit: "PX"
                                }
                            }, {
                                id: "a-7-n-7",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "68f124d186cdc4458065856f|1a599200-6b41-92aa-9bb2-275f6707530d"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }, {
                                id: "a-7-n-5",
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "68f124d186cdc4458065856f|1a599200-6b41-92aa-9bb2-275f6707530d"
                                    },
                                    yValue: -100,
                                    xUnit: "PX",
                                    yUnit: "%",
                                    zUnit: "PX"
                                }
                            }, {
                                id: "a-7-n-3",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "68f124d186cdc4458065856f|7efae36f-7250-7c58-be50-1a28976d996e"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-7-n-2",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 200,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        id: "68f124d186cdc4458065856f|f62816b4-c386-9eee-2b17-30f69cf2c757"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }, {
                                id: "a-7-n-4",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 200,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        id: "68f124d186cdc4458065856f|7efae36f-7250-7c58-be50-1a28976d996e"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-7-n-6",
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 200,
                                    target: {
                                        id: "68f124d186cdc4458065856f|1a599200-6b41-92aa-9bb2-275f6707530d"
                                    },
                                    yValue: 0,
                                    xUnit: "PX",
                                    yUnit: "%",
                                    zUnit: "PX"
                                }
                            }, {
                                id: "a-7-n-8",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "easeIn",
                                    duration: 200,
                                    target: {
                                        id: "68f124d186cdc4458065856f|1a599200-6b41-92aa-9bb2-275f6707530d"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-7-n-10",
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "easeIn",
                                    duration: 300,
                                    target: {
                                        id: "68f124d186cdc4458065856f|04fafe08-069b-504a-f2ee-60d45e2bf7b1"
                                    },
                                    yValue: 0,
                                    xUnit: "PX",
                                    yUnit: "px",
                                    zUnit: "PX"
                                }
                            }, {
                                id: "a-7-n-12",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 300,
                                    target: {
                                        id: "68f124d186cdc4458065856f|04fafe08-069b-504a-f2ee-60d45e2bf7b1"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-7-n-14",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "easeIn",
                                    duration: 200,
                                    target: {
                                        id: "68f124d186cdc4458065856f|e8ca681d-e259-b96a-8672-e4177ec7f4b9"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-7-n-17",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 200,
                                    target: {
                                        id: "68f124d186cdc4458065856f|726abba1-326a-32db-958f-4cbc02a2d9c6"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }, {
                                id: "a-7-n-18",
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "easeIn",
                                    duration: 200,
                                    target: {
                                        id: "68f124d186cdc4458065856f|726abba1-326a-32db-958f-4cbc02a2d9c6"
                                    },
                                    yValue: 0,
                                    xUnit: "PX",
                                    yUnit: "px",
                                    zUnit: "PX"
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-7-n-21",
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 200,
                                    target: {
                                        id: "68f124d186cdc4458065856f|726abba1-326a-32db-958f-4cbc02a2d9c8"
                                    },
                                    yValue: 0,
                                    xUnit: "PX",
                                    yUnit: "px",
                                    zUnit: "PX"
                                }
                            }, {
                                id: "a-7-n-22",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 200,
                                    target: {
                                        id: "68f124d186cdc4458065856f|726abba1-326a-32db-958f-4cbc02a2d9c8"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-7-n-24",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "easeInOut",
                                    duration: 300,
                                    target: {
                                        id: "68f124d186cdc4458065856f|05961cb1-b97d-309f-af30-4a201f1173d7"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !0,
                        createdOn: 0x19a09224aa4
                    },
                    "a-8": {
                        id: "a-8",
                        title: "Header-Animation",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-8-n",
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "90793150-c860-8f6a-58b5-019f8281f08c"
                                    },
                                    yValue: -80,
                                    xUnit: "PX",
                                    yUnit: "px",
                                    zUnit: "PX"
                                }
                            }, {
                                id: "a-8-n-9",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "c26623d9-9550-a008-4664-3b59c60aa156"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }, {
                                id: "a-8-n-7",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "341fca05-e4e7-9f05-388b-623ffa1f4c5a"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }, {
                                id: "a-8-n-5",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "35a59322-6ca6-87bb-efa7-5fe39cb1dd55"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }, {
                                id: "a-8-n-3",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "90793150-c860-8f6a-58b5-019f8281f08c"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-8-n-2",
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: [0, .977, .345, .147],
                                    duration: 800,
                                    target: {
                                        id: "90793150-c860-8f6a-58b5-019f8281f08c"
                                    },
                                    yValue: 0,
                                    xUnit: "PX",
                                    yUnit: "px",
                                    zUnit: "PX"
                                }
                            }, {
                                id: "a-8-n-4",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "easeIn",
                                    duration: 600,
                                    target: {
                                        id: "90793150-c860-8f6a-58b5-019f8281f08c"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-8-n-6",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "easeIn",
                                    duration: 500,
                                    target: {
                                        id: "35a59322-6ca6-87bb-efa7-5fe39cb1dd55"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }, {
                                id: "a-8-n-8",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 800,
                                    target: {
                                        id: "341fca05-e4e7-9f05-388b-623ffa1f4c5a"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-8-n-10",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "inQuad",
                                    duration: 500,
                                    target: {
                                        id: "c26623d9-9550-a008-4664-3b59c60aa156"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !0,
                        createdOn: 0x19a0cdff624
                    },
                    "a-9": {
                        id: "a-9",
                        title: "Open FAQ",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-9-n",
                                actionTypeId: "STYLE_SIZE",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "SIBLINGS",
                                        selector: ".faq-answer",
                                        selectorGuids: ["02700e1e-9837-1ded-f3eb-217bfe8dc563"]
                                    },
                                    heightValue: 0,
                                    widthUnit: "PX",
                                    heightUnit: "px",
                                    locked: !1
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-9-n-2",
                                actionTypeId: "STYLE_SIZE",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 300,
                                    target: {
                                        useEventTarget: "SIBLINGS",
                                        selector: ".faq-answer",
                                        selectorGuids: ["02700e1e-9837-1ded-f3eb-217bfe8dc563"]
                                    },
                                    widthUnit: "PX",
                                    heightUnit: "AUTO",
                                    locked: !1
                                }
                            }, {
                                id: "a-9-n-3",
                                actionTypeId: "STYLE_SIZE",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 300,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".plus",
                                        selectorGuids: ["02700e1e-9837-1ded-f3eb-217bfe8dc56a"]
                                    },
                                    heightValue: 0,
                                    widthUnit: "PX",
                                    heightUnit: "%",
                                    locked: !1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !0,
                        createdOn: 0x181858680d7
                    },
                    "a-10": {
                        id: "a-10",
                        title: "Close FAQ",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-10-n",
                                actionTypeId: "STYLE_SIZE",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 300,
                                    target: {
                                        useEventTarget: "SIBLINGS",
                                        selector: ".faq-answer",
                                        selectorGuids: ["02700e1e-9837-1ded-f3eb-217bfe8dc563"]
                                    },
                                    heightValue: 0,
                                    widthUnit: "PX",
                                    heightUnit: "px",
                                    locked: !1
                                }
                            }, {
                                id: "a-10-n-2",
                                actionTypeId: "STYLE_SIZE",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 300,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".plus",
                                        selectorGuids: ["02700e1e-9837-1ded-f3eb-217bfe8dc56a"]
                                    },
                                    heightValue: 100,
                                    widthUnit: "PX",
                                    heightUnit: "%",
                                    locked: !1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x181858680d7
                    },
                    "a-14": {
                        id: "a-14",
                        title: "Timeline- Traitures",
                        continuousParameterGroups: [{
                            id: "a-14-p",
                            type: "SCROLL_PROGRESS",
                            parameterLabel: "Scroll",
                            continuousActionGroups: [{
                                keyframe: 0,
                                actionItems: [{
                                    id: "a-14-n",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            id: "69013955b2b4f2ab0d0b5a3e|a84c00e1-2e03-6ea3-a7ca-e21dcf512eae"
                                        },
                                        value: 0,
                                        unit: ""
                                    }
                                }, {
                                    id: "a-14-n-3",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|7718b673-68cd-63ff-fff1-92579e8f40a2"
                                        },
                                        value: 0,
                                        unit: ""
                                    }
                                }, {
                                    id: "a-14-n-5",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|7718b673-68cd-63ff-fff1-92579e8f40a4"
                                        },
                                        value: 0,
                                        unit: ""
                                    }
                                }]
                            }, {
                                keyframe: 21,
                                actionItems: [{
                                    id: "a-14-n-7",
                                    actionTypeId: "STYLE_SIZE",
                                    config: {
                                        delay: 0,
                                        easing: "easeIn",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|1a2f0bb9-d765-ab13-c338-1b8ab478bc78"
                                        },
                                        heightValue: 0,
                                        widthUnit: "PX",
                                        heightUnit: "px",
                                        locked: !1
                                    }
                                }]
                            }, {
                                keyframe: 24,
                                actionItems: [{
                                    id: "a-14-n-2",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "easeIn",
                                        duration: 500,
                                        target: {
                                            id: "69013955b2b4f2ab0d0b5a3e|a84c00e1-2e03-6ea3-a7ca-e21dcf512eae"
                                        },
                                        value: 1,
                                        unit: ""
                                    }
                                }, {
                                    id: "a-14-n-4",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "easeIn",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|7718b673-68cd-63ff-fff1-92579e8f40a2"
                                        },
                                        value: 1,
                                        unit: ""
                                    }
                                }, {
                                    id: "a-14-n-6",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "easeIn",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|7718b673-68cd-63ff-fff1-92579e8f40a4"
                                        },
                                        value: 1,
                                        unit: ""
                                    }
                                }]
                            }, {
                                keyframe: 28,
                                actionItems: [{
                                    id: "a-14-n-9",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "easeIn",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|0616915a-ea2f-a356-1b86-2e667363f045"
                                        },
                                        value: 0,
                                        unit: ""
                                    }
                                }, {
                                    id: "a-14-n-11",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "easeIn",
                                        duration: 500,
                                        target: {
                                            id: "69013955b2b4f2ab0d0b5a3e|b1c09bf6-07ad-99b0-3706-edf48680ff9a"
                                        },
                                        value: 0,
                                        unit: ""
                                    }
                                }]
                            }, {
                                keyframe: 32,
                                actionItems: [{
                                    id: "a-14-n-13",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|0616915a-ea2f-a356-1b86-2e667363f047"
                                        },
                                        value: 0,
                                        unit: ""
                                    }
                                }]
                            }, {
                                keyframe: 33,
                                actionItems: [{
                                    id: "a-14-n-8",
                                    actionTypeId: "STYLE_SIZE",
                                    config: {
                                        delay: 0,
                                        easing: "easeIn",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|1a2f0bb9-d765-ab13-c338-1b8ab478bc78"
                                        },
                                        heightValue: 330,
                                        widthUnit: "PX",
                                        heightUnit: "px",
                                        locked: !1
                                    }
                                }]
                            }, {
                                keyframe: 47,
                                actionItems: [{
                                    id: "a-14-n-10",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "easeIn",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|0616915a-ea2f-a356-1b86-2e667363f045"
                                        },
                                        value: 1,
                                        unit: ""
                                    }
                                }, {
                                    id: "a-14-n-12",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "easeIn",
                                        duration: 500,
                                        target: {
                                            id: "69013955b2b4f2ab0d0b5a3e|b1c09bf6-07ad-99b0-3706-edf48680ff9a"
                                        },
                                        value: 1,
                                        unit: ""
                                    }
                                }, {
                                    id: "a-14-n-14",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|0616915a-ea2f-a356-1b86-2e667363f047"
                                        },
                                        value: 1,
                                        unit: ""
                                    }
                                }]
                            }, {
                                keyframe: 50,
                                actionItems: [{
                                    id: "a-14-n-15",
                                    actionTypeId: "STYLE_SIZE",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|b1c09bf6-07ad-99b0-3706-edf48680ff9b"
                                        },
                                        heightValue: 0,
                                        widthUnit: "PX",
                                        heightUnit: "px",
                                        locked: !1
                                    }
                                }, {
                                    id: "a-14-n-17",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|2135d8ea-a2e2-102f-4e72-1284553e4039"
                                        },
                                        value: 0,
                                        unit: ""
                                    }
                                }, {
                                    id: "a-14-n-19",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|2135d8ea-a2e2-102f-4e72-1284553e403b"
                                        },
                                        value: 0,
                                        unit: ""
                                    }
                                }, {
                                    id: "a-14-n-21",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            id: "69013955b2b4f2ab0d0b5a3e|a7eb0750-5527-b196-8e36-beafb029d589"
                                        },
                                        value: 0,
                                        unit: ""
                                    }
                                }]
                            }, {
                                keyframe: 63,
                                actionItems: [{
                                    id: "a-14-n-16",
                                    actionTypeId: "STYLE_SIZE",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|b1c09bf6-07ad-99b0-3706-edf48680ff9b"
                                        },
                                        heightValue: 330,
                                        widthUnit: "PX",
                                        heightUnit: "px",
                                        locked: !1
                                    }
                                }]
                            }, {
                                keyframe: 70,
                                actionItems: [{
                                    id: "a-14-n-18",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|2135d8ea-a2e2-102f-4e72-1284553e4039"
                                        },
                                        value: 1,
                                        unit: ""
                                    }
                                }, {
                                    id: "a-14-n-20",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            useEventTarget: "CHILDREN",
                                            id: "69013955b2b4f2ab0d0b5a3e|2135d8ea-a2e2-102f-4e72-1284553e403b"
                                        },
                                        value: 1,
                                        unit: ""
                                    }
                                }, {
                                    id: "a-14-n-22",
                                    actionTypeId: "STYLE_OPACITY",
                                    config: {
                                        delay: 0,
                                        easing: "",
                                        duration: 500,
                                        target: {
                                            id: "69013955b2b4f2ab0d0b5a3e|a7eb0750-5527-b196-8e36-beafb029d589"
                                        },
                                        value: 1,
                                        unit: ""
                                    }
                                }]
                            }]
                        }],
                        createdOn: 0x19a50f49dd7
                    },
                    "a-16": {
                        id: "a-16",
                        title: "Line-opacity",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-16-n-3",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: "._40px-line-width",
                                        selectorGuids: ["f1b28247-fbb0-5cab-0c30-4e03dc446d27"]
                                    },
                                    value: .35,
                                    unit: ""
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-16-n-4",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: "._40px-line-width",
                                        selectorGuids: ["f1b28247-fbb0-5cab-0c30-4e03dc446d27"]
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !0,
                        createdOn: 0x19a557f77a2
                    },
                    "a-17": {
                        id: "a-17",
                        title: "button-loop-animation",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-17-n",
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        id: "69024379e409e4655b186c43|b69a6620-6c81-7f43-c5a0-9e86e9b2487e"
                                    },
                                    xValue: 100,
                                    xUnit: "vw",
                                    yUnit: "PX",
                                    zUnit: "PX"
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-17-n-2",
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 2e4,
                                    target: {
                                        id: "69024379e409e4655b186c43|b69a6620-6c81-7f43-c5a0-9e86e9b2487e"
                                    },
                                    xValue: -250,
                                    xUnit: "vw",
                                    yUnit: "PX",
                                    zUnit: "PX"
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-17-n-3",
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        id: "69024379e409e4655b186c43|b69a6620-6c81-7f43-c5a0-9e86e9b2487e"
                                    },
                                    xValue: 100,
                                    xUnit: "vw",
                                    yUnit: "PX",
                                    zUnit: "PX"
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !0,
                        createdOn: 0x19a5584751c
                    },
                    "a-18": {
                        id: "a-18",
                        title: "Logo-in-hover",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-18-n",
                                actionTypeId: "TRANSFORM_SCALE",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: !0,
                                        id: "c26623d9-9550-a008-4664-3b59c60aa156"
                                    },
                                    xValue: .9,
                                    yValue: .9,
                                    locked: !0
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x19a5a9d50e2
                    },
                    "a-19": {
                        id: "a-19",
                        title: "Logo-out-hover",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-19-n",
                                actionTypeId: "TRANSFORM_SCALE",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: !0,
                                        id: "c26623d9-9550-a008-4664-3b59c60aa156"
                                    },
                                    xValue: 1,
                                    yValue: 1,
                                    locked: !0
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x19a5a9d50e2
                    },
                    "a-20": {
                        id: "a-20",
                        title: "Card-1-green-rickshaw-hover-in",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-20-n",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 300,
                                    target: {
                                        id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a"
                                    },
                                    globalSwatchId: "--olive",
                                    rValue: 128,
                                    bValue: 0,
                                    gValue: 128,
                                    aValue: 1
                                }
                            }, {
                                id: "a-20-n-8",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".hide-image",
                                        selectorGuids: ["a397c959-64b7-e747-c512-79503a04cc3d"]
                                    },
                                    value: "block"
                                }
                            }, {
                                id: "a-20-n-7",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".lottie-animation-3",
                                        selectorGuids: ["da78a815-c4c9-45f3-99b9-639d40e0fc5c"]
                                    },
                                    value: "none"
                                }
                            }, {
                                id: "a-20-n-6",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".link_underline",
                                        selectorGuids: ["4f7543e8-fb70-7c01-5f0f-cd837b29d791"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-20-n-5",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".paragraph.small-size.pd-left",
                                        selectorGuids: ["e7d4f0d9-6c5e-b342-df95-f307a3ec5967", "009ea448-84f6-81f1-01c0-7c7f6c7cffc0", "694bdfb1-f517-705f-395a-bc36da68612c"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-20-n-4",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".h3.capitalize",
                                        selectorGuids: ["0ca471d7-f571-557c-72bb-15b7b4755632", "ffe8110e-1f35-3dfc-ea61-a50bb08ab29b"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x19a5b56f062
                    },
                    "a-23": {
                        id: "a-23",
                        title: "Card-1-green-rickshaw-hover-out 1",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-23-n",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 300,
                                    target: {
                                        id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a"
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-23-n-2",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".hide-image",
                                        selectorGuids: ["a397c959-64b7-e747-c512-79503a04cc3d"]
                                    },
                                    value: "none"
                                }
                            }, {
                                id: "a-23-n-3",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".lottie-animation-3",
                                        selectorGuids: ["da78a815-c4c9-45f3-99b9-639d40e0fc5c"]
                                    },
                                    value: "block"
                                }
                            }, {
                                id: "a-23-n-4",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".link_underline",
                                        selectorGuids: ["4f7543e8-fb70-7c01-5f0f-cd837b29d791"]
                                    },
                                    globalSwatchId: "--olive",
                                    rValue: 128,
                                    bValue: 0,
                                    gValue: 128,
                                    aValue: 1
                                }
                            }, {
                                id: "a-23-n-5",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".paragraph.small-size.pd-left",
                                        selectorGuids: ["e7d4f0d9-6c5e-b342-df95-f307a3ec5967", "009ea448-84f6-81f1-01c0-7c7f6c7cffc0", "694bdfb1-f517-705f-395a-bc36da68612c"]
                                    },
                                    globalSwatchId: "--text",
                                    rValue: 107,
                                    bValue: 107,
                                    gValue: 107,
                                    aValue: 1
                                }
                            }, {
                                id: "a-23-n-6",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".h3.capitalize",
                                        selectorGuids: ["0ca471d7-f571-557c-72bb-15b7b4755632", "ffe8110e-1f35-3dfc-ea61-a50bb08ab29b"]
                                    },
                                    globalSwatchId: "--olive",
                                    rValue: 128,
                                    bValue: 0,
                                    gValue: 128,
                                    aValue: 1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x19a5b56f062
                    },
                    "a-21": {
                        id: "a-21",
                        title: "Card-1-red-bike-hover-in 2",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-21-n-2",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".link_underline",
                                        selectorGuids: ["4f7543e8-fb70-7c01-5f0f-cd837b29d791"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-21-n-8",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".hide-image",
                                        selectorGuids: ["a397c959-64b7-e747-c512-79503a04cc3d"]
                                    },
                                    value: "block"
                                }
                            }, {
                                id: "a-21-n-7",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".lottie-animation-3",
                                        selectorGuids: ["da78a815-c4c9-45f3-99b9-639d40e0fc5c"]
                                    },
                                    value: "none"
                                }
                            }, {
                                id: "a-21-n-6",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: !0,
                                        id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acc"
                                    },
                                    globalSwatchId: "--primary",
                                    rValue: 244,
                                    bValue: 31,
                                    gValue: 66,
                                    aValue: 1
                                }
                            }, {
                                id: "a-21-n-3",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".paragraph.small-size.pd-left",
                                        selectorGuids: ["e7d4f0d9-6c5e-b342-df95-f307a3ec5967", "009ea448-84f6-81f1-01c0-7c7f6c7cffc0", "694bdfb1-f517-705f-395a-bc36da68612c"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-21-n-4",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".h3.capitalize",
                                        selectorGuids: ["0ca471d7-f571-557c-72bb-15b7b4755632", "ffe8110e-1f35-3dfc-ea61-a50bb08ab29b"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x19a5b56f062
                    },
                    "a-22": {
                        id: "a-22",
                        title: "Card-2-red-bike-hover-out 2",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-22-n",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".link_underline",
                                        selectorGuids: ["4f7543e8-fb70-7c01-5f0f-cd837b29d791"]
                                    },
                                    globalSwatchId: "--primary",
                                    rValue: 244,
                                    bValue: 31,
                                    gValue: 66,
                                    aValue: 1
                                }
                            }, {
                                id: "a-22-n-2",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".hide-image",
                                        selectorGuids: ["a397c959-64b7-e747-c512-79503a04cc3d"]
                                    },
                                    value: "none"
                                }
                            }, {
                                id: "a-22-n-3",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".lottie-animation-3",
                                        selectorGuids: ["da78a815-c4c9-45f3-99b9-639d40e0fc5c"]
                                    },
                                    value: "block"
                                }
                            }, {
                                id: "a-22-n-4",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: !0,
                                        id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acc"
                                    },
                                    globalSwatchId: "",
                                    rValue: 0,
                                    bValue: 0,
                                    gValue: 0,
                                    aValue: 0
                                }
                            }, {
                                id: "a-22-n-5",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".paragraph.small-size.pd-left",
                                        selectorGuids: ["e7d4f0d9-6c5e-b342-df95-f307a3ec5967", "009ea448-84f6-81f1-01c0-7c7f6c7cffc0", "694bdfb1-f517-705f-395a-bc36da68612c"]
                                    },
                                    globalSwatchId: "--text",
                                    rValue: 107,
                                    bValue: 107,
                                    gValue: 107,
                                    aValue: 1
                                }
                            }, {
                                id: "a-22-n-6",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".h3.capitalize",
                                        selectorGuids: ["0ca471d7-f571-557c-72bb-15b7b4755632", "ffe8110e-1f35-3dfc-ea61-a50bb08ab29b"]
                                    },
                                    globalSwatchId: "--primary",
                                    rValue: 244,
                                    bValue: 31,
                                    gValue: 66,
                                    aValue: 1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x19a5b56f062
                    },
                    "a-24": {
                        id: "a-24",
                        title: "Cards-animation",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-24-n",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|9b671b9d-f0ae-73ff-83d8-02a6a5166163"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }, {
                                id: "a-24-n-7",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|a2e2d5a4-b390-2137-a393-4bb0839f9e28"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }, {
                                id: "a-24-n-5",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|34f2af5d-e0b6-c582-4717-0a7978d3afd0"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }, {
                                id: "a-24-n-3",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|4083c9c2-c99e-901b-c3a5-3db7ae8e2e4a"
                                    },
                                    value: 0,
                                    unit: ""
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-24-n-2",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 200,
                                    easing: "ease",
                                    duration: 800,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|9b671b9d-f0ae-73ff-83d8-02a6a5166163"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }, {
                                id: "a-24-n-4",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 500,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|4083c9c2-c99e-901b-c3a5-3db7ae8e2e4a"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-24-n-6",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|34f2af5d-e0b6-c582-4717-0a7978d3afd0"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }]
                        }, {
                            actionItems: [{
                                id: "a-24-n-8",
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "easeIn",
                                    duration: 600,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|a2e2d5a4-b390-2137-a393-4bb0839f9e28"
                                    },
                                    value: 1,
                                    unit: ""
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !0,
                        createdOn: 0x19a5c0cbbca
                    },
                    "a-26": {
                        id: "a-26",
                        title: "Card-1-black-noodel-hover-in",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-26-n-7",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: !0,
                                        id: "68f124d186cdc4458065856f|167320bf-8854-4bc8-2064-066478b0eb17"
                                    },
                                    globalSwatchId: "--secondary",
                                    rValue: 44,
                                    bValue: 44,
                                    gValue: 44,
                                    aValue: 1
                                }
                            }, {
                                id: "a-26-n-2",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".hide-image",
                                        selectorGuids: ["a397c959-64b7-e747-c512-79503a04cc3d"]
                                    },
                                    value: "block"
                                }
                            }, {
                                id: "a-26-n-3",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".lottie-animation-3",
                                        selectorGuids: ["da78a815-c4c9-45f3-99b9-639d40e0fc5c"]
                                    },
                                    value: "none"
                                }
                            }, {
                                id: "a-26-n-4",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".link_underline",
                                        selectorGuids: ["4f7543e8-fb70-7c01-5f0f-cd837b29d791"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-26-n-5",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".paragraph.small-size.pd-left",
                                        selectorGuids: ["e7d4f0d9-6c5e-b342-df95-f307a3ec5967", "009ea448-84f6-81f1-01c0-7c7f6c7cffc0", "694bdfb1-f517-705f-395a-bc36da68612c"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-26-n-6",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".h3.capitalize",
                                        selectorGuids: ["0ca471d7-f571-557c-72bb-15b7b4755632", "ffe8110e-1f35-3dfc-ea61-a50bb08ab29b"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x19a5b56f062
                    },
                    "a-27": {
                        id: "a-27",
                        title: "Card-3-black-bike-hover-out 3",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-27-n",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".link_underline",
                                        selectorGuids: ["4f7543e8-fb70-7c01-5f0f-cd837b29d791"]
                                    },
                                    globalSwatchId: "--secondary",
                                    rValue: 44,
                                    bValue: 44,
                                    gValue: 44,
                                    aValue: 1
                                }
                            }, {
                                id: "a-27-n-2",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".hide-image",
                                        selectorGuids: ["a397c959-64b7-e747-c512-79503a04cc3d"]
                                    },
                                    value: "none"
                                }
                            }, {
                                id: "a-27-n-3",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".lottie-animation-3",
                                        selectorGuids: ["da78a815-c4c9-45f3-99b9-639d40e0fc5c"]
                                    },
                                    value: "block"
                                }
                            }, {
                                id: "a-27-n-4",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: !0,
                                        id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acc"
                                    },
                                    globalSwatchId: "",
                                    rValue: 0,
                                    bValue: 0,
                                    gValue: 0,
                                    aValue: 0
                                }
                            }, {
                                id: "a-27-n-5",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".paragraph.small-size.pd-left",
                                        selectorGuids: ["e7d4f0d9-6c5e-b342-df95-f307a3ec5967", "009ea448-84f6-81f1-01c0-7c7f6c7cffc0", "694bdfb1-f517-705f-395a-bc36da68612c"]
                                    },
                                    globalSwatchId: "--text",
                                    rValue: 107,
                                    bValue: 107,
                                    gValue: 107,
                                    aValue: 1
                                }
                            }, {
                                id: "a-27-n-6",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "ease",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".h3.capitalize",
                                        selectorGuids: ["0ca471d7-f571-557c-72bb-15b7b4755632", "ffe8110e-1f35-3dfc-ea61-a50bb08ab29b"]
                                    },
                                    globalSwatchId: "--secondary",
                                    rValue: 44,
                                    bValue: 44,
                                    gValue: 44,
                                    aValue: 1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x19a5b56f062
                    },
                    "a-30": {
                        id: "a-30",
                        title: "mobile-scroll-in-view card 2",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-30-n",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: !0,
                                        id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acc"
                                    },
                                    globalSwatchId: "--primary",
                                    rValue: 244,
                                    bValue: 31,
                                    gValue: 66,
                                    aValue: 1
                                }
                            }, {
                                id: "a-30-n-2",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|f6123d0c-7074-8fc8-99dc-164b19897f91"
                                    },
                                    value: "none"
                                }
                            }, {
                                id: "a-30-n-3",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|b767d163-0e2a-7455-744d-9d603afe201b"
                                    },
                                    value: "block"
                                }
                            }, {
                                id: "a-30-n-4",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096ad3"
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-30-n-5",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096ad1"
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-30-n-6",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acf"
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x19a70394059
                    },
                    "a-31": {
                        id: "a-31",
                        title: "mobile-scroll-out-view card 2-middle",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-31-n",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: !0,
                                        id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a"
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-31-n-2",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|f6123d0c-7074-8fc8-99dc-164b19897f91"
                                    },
                                    value: "block"
                                }
                            }, {
                                id: "a-31-n-3",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|b767d163-0e2a-7455-744d-9d603afe201b"
                                    },
                                    value: "none"
                                }
                            }, {
                                id: "a-31-n-4",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096ad3"
                                    },
                                    globalSwatchId: "--primary",
                                    rValue: 244,
                                    bValue: 31,
                                    gValue: 66,
                                    aValue: 1
                                }
                            }, {
                                id: "a-31-n-5",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096ad1"
                                    },
                                    globalSwatchId: "--text",
                                    rValue: 107,
                                    bValue: 107,
                                    gValue: 107,
                                    aValue: 1
                                }
                            }, {
                                id: "a-31-n-6",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|d1866bd0-dc75-a001-08c0-99e1fd096acf"
                                    },
                                    globalSwatchId: "--primary",
                                    rValue: 244,
                                    bValue: 31,
                                    gValue: 66,
                                    aValue: 1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x19a70394059
                    },
                    "a-28": {
                        id: "a-28",
                        title: "mobile-scroll-in-view",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-28-n",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: !0,
                                        id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a"
                                    },
                                    globalSwatchId: "--olive",
                                    rValue: 128,
                                    bValue: 0,
                                    gValue: 128,
                                    aValue: 1
                                }
                            }, {
                                id: "a-28-n-6",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".lottie-animation-3",
                                        selectorGuids: ["da78a815-c4c9-45f3-99b9-639d40e0fc5c"]
                                    },
                                    value: "none"
                                }
                            }, {
                                id: "a-28-n-5",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".hide-image",
                                        selectorGuids: ["a397c959-64b7-e747-c512-79503a04cc3d"]
                                    },
                                    value: "block"
                                }
                            }, {
                                id: "a-28-n-4",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".link_underline",
                                        selectorGuids: ["4f7543e8-fb70-7c01-5f0f-cd837b29d791"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-28-n-3",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".paragraph.small-size.pd-left",
                                        selectorGuids: ["e7d4f0d9-6c5e-b342-df95-f307a3ec5967", "009ea448-84f6-81f1-01c0-7c7f6c7cffc0", "694bdfb1-f517-705f-395a-bc36da68612c"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-28-n-2",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".h3.capitalize",
                                        selectorGuids: ["0ca471d7-f571-557c-72bb-15b7b4755632", "ffe8110e-1f35-3dfc-ea61-a50bb08ab29b"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x19a70394059
                    },
                    "a-29": {
                        id: "a-29",
                        title: "mobile-scroll-out-view card 1",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-29-n",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: !0,
                                        id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a"
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-29-n-2",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".lottie-animation-3",
                                        selectorGuids: ["da78a815-c4c9-45f3-99b9-639d40e0fc5c"]
                                    },
                                    value: "block"
                                }
                            }, {
                                id: "a-29-n-3",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".hide-image",
                                        selectorGuids: ["a397c959-64b7-e747-c512-79503a04cc3d"]
                                    },
                                    value: "none"
                                }
                            }, {
                                id: "a-29-n-4",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".link_underline",
                                        selectorGuids: ["4f7543e8-fb70-7c01-5f0f-cd837b29d791"]
                                    },
                                    globalSwatchId: "--olive",
                                    rValue: 128,
                                    bValue: 0,
                                    gValue: 128,
                                    aValue: 1
                                }
                            }, {
                                id: "a-29-n-5",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".paragraph.small-size.pd-left",
                                        selectorGuids: ["e7d4f0d9-6c5e-b342-df95-f307a3ec5967", "009ea448-84f6-81f1-01c0-7c7f6c7cffc0", "694bdfb1-f517-705f-395a-bc36da68612c"]
                                    },
                                    globalSwatchId: "--text",
                                    rValue: 107,
                                    bValue: 107,
                                    gValue: 107,
                                    aValue: 1
                                }
                            }, {
                                id: "a-29-n-6",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".h3.capitalize",
                                        selectorGuids: ["0ca471d7-f571-557c-72bb-15b7b4755632", "ffe8110e-1f35-3dfc-ea61-a50bb08ab29b"]
                                    },
                                    globalSwatchId: "--olive",
                                    rValue: 128,
                                    bValue: 0,
                                    gValue: 128,
                                    aValue: 1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x19a70394059
                    },
                    "a-32": {
                        id: "a-32",
                        title: "mobile-scroll-in-view card 3",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-32-n",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: !0,
                                        id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a"
                                    },
                                    globalSwatchId: "--secondary",
                                    rValue: 44,
                                    bValue: 44,
                                    gValue: 44,
                                    aValue: 1
                                }
                            }, {
                                id: "a-32-n-2",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".lottie-animation-3",
                                        selectorGuids: ["da78a815-c4c9-45f3-99b9-639d40e0fc5c"]
                                    },
                                    value: "none"
                                }
                            }, {
                                id: "a-32-n-3",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".hide-image",
                                        selectorGuids: ["a397c959-64b7-e747-c512-79503a04cc3d"]
                                    },
                                    value: "block"
                                }
                            }, {
                                id: "a-32-n-4",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".link_underline",
                                        selectorGuids: ["4f7543e8-fb70-7c01-5f0f-cd837b29d791"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-32-n-5",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".paragraph.small-size.pd-left",
                                        selectorGuids: ["e7d4f0d9-6c5e-b342-df95-f307a3ec5967", "009ea448-84f6-81f1-01c0-7c7f6c7cffc0", "694bdfb1-f517-705f-395a-bc36da68612c"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-32-n-6",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        selector: ".h3.capitalize",
                                        selectorGuids: ["0ca471d7-f571-557c-72bb-15b7b4755632", "ffe8110e-1f35-3dfc-ea61-a50bb08ab29b"]
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x19a70394059
                    },
                    "a-33": {
                        id: "a-33",
                        title: "mobile-scroll-out-view card 2-middle 2",
                        actionItemGroups: [{
                            actionItems: [{
                                id: "a-33-n",
                                actionTypeId: "STYLE_BACKGROUND_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: !0,
                                        id: "68f124d186cdc4458065856f|fec7de4b-ec52-cea0-2ba3-cea94842795a"
                                    },
                                    globalSwatchId: "--white",
                                    rValue: 245,
                                    bValue: 236,
                                    gValue: 242,
                                    aValue: 1
                                }
                            }, {
                                id: "a-33-n-2",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|1142337f-3cd3-a19a-bf7c-b2085a5e102d"
                                    },
                                    value: "block"
                                }
                            }, {
                                id: "a-33-n-3",
                                actionTypeId: "GENERAL_DISPLAY",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 0,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|4c6a10af-4720-c450-2e76-aa5ed4878b0f"
                                    },
                                    value: "none"
                                }
                            }, {
                                id: "a-33-n-4",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|167320bf-8854-4bc8-2064-066478b0eb1e"
                                    },
                                    globalSwatchId: "--secondary",
                                    rValue: 44,
                                    bValue: 44,
                                    gValue: 44,
                                    aValue: 1
                                }
                            }, {
                                id: "a-33-n-5",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|167320bf-8854-4bc8-2064-066478b0eb1c"
                                    },
                                    globalSwatchId: "--text",
                                    rValue: 107,
                                    bValue: 107,
                                    gValue: 107,
                                    aValue: 1
                                }
                            }, {
                                id: "a-33-n-6",
                                actionTypeId: "STYLE_TEXT_COLOR",
                                config: {
                                    delay: 0,
                                    easing: "",
                                    duration: 500,
                                    target: {
                                        useEventTarget: "CHILDREN",
                                        id: "68f124d186cdc4458065856f|167320bf-8854-4bc8-2064-066478b0eb1a"
                                    },
                                    globalSwatchId: "--secondary",
                                    rValue: 44,
                                    bValue: 44,
                                    gValue: 44,
                                    aValue: 1
                                }
                            }]
                        }],
                        useFirstGroupAsInitialState: !1,
                        createdOn: 0x19a70394059
                    },
                    slideInTop: {
                        id: "slideInTop",
                        useFirstGroupAsInitialState: !0,
                        actionItemGroups: [{
                            actionItems: [{
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    duration: 0,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    value: 0
                                }
                            }]
                        }, {
                            actionItems: [{
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    duration: 0,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    xValue: 0,
                                    yValue: -100,
                                    xUnit: "PX",
                                    yUnit: "PX",
                                    zUnit: "PX"
                                }
                            }]
                        }, {
                            actionItems: [{
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "outQuart",
                                    duration: 1e3,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    value: 1
                                }
                            }, {
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "outQuart",
                                    duration: 1e3,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    xValue: 0,
                                    yValue: 0,
                                    xUnit: "PX",
                                    yUnit: "PX",
                                    zUnit: "PX"
                                }
                            }]
                        }]
                    },
                    slideInBottom: {
                        id: "slideInBottom",
                        useFirstGroupAsInitialState: !0,
                        actionItemGroups: [{
                            actionItems: [{
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    duration: 0,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    value: 0
                                }
                            }]
                        }, {
                            actionItems: [{
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    duration: 0,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    xValue: 0,
                                    yValue: 100,
                                    xUnit: "PX",
                                    yUnit: "PX",
                                    zUnit: "PX"
                                }
                            }]
                        }, {
                            actionItems: [{
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "outQuart",
                                    duration: 1e3,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    xValue: 0,
                                    yValue: 0,
                                    xUnit: "PX",
                                    yUnit: "PX",
                                    zUnit: "PX"
                                }
                            }, {
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "outQuart",
                                    duration: 1e3,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    value: 1
                                }
                            }]
                        }]
                    },
                    fadeIn: {
                        id: "fadeIn",
                        useFirstGroupAsInitialState: !0,
                        actionItemGroups: [{
                            actionItems: [{
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    duration: 0,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    value: 0
                                }
                            }]
                        }, {
                            actionItems: [{
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "outQuart",
                                    duration: 1e3,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    value: 1
                                }
                            }]
                        }]
                    },
                    slideInLeft: {
                        id: "slideInLeft",
                        useFirstGroupAsInitialState: !0,
                        actionItemGroups: [{
                            actionItems: [{
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    duration: 0,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    value: 0
                                }
                            }]
                        }, {
                            actionItems: [{
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    duration: 0,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    xValue: -100,
                                    yValue: 0,
                                    xUnit: "PX",
                                    yUnit: "PX",
                                    zUnit: "PX"
                                }
                            }]
                        }, {
                            actionItems: [{
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "outQuart",
                                    duration: 1e3,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    value: 1
                                }
                            }, {
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "outQuart",
                                    duration: 1e3,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    xValue: 0,
                                    yValue: 0,
                                    xUnit: "PX",
                                    yUnit: "PX",
                                    zUnit: "PX"
                                }
                            }]
                        }]
                    },
                    shrinkIn: {
                        id: "shrinkIn",
                        useFirstGroupAsInitialState: !0,
                        actionItemGroups: [{
                            actionItems: [{
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    duration: 0,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    value: 0
                                }
                            }]
                        }, {
                            actionItems: [{
                                actionTypeId: "TRANSFORM_SCALE",
                                config: {
                                    delay: 0,
                                    duration: 0,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    xValue: 1.25,
                                    yValue: 1.25
                                }
                            }]
                        }, {
                            actionItems: [{
                                actionTypeId: "TRANSFORM_SCALE",
                                config: {
                                    delay: 0,
                                    easing: "outQuart",
                                    duration: 1e3,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    xValue: 1,
                                    yValue: 1
                                }
                            }, {
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "outQuart",
                                    duration: 1e3,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    value: 1
                                }
                            }]
                        }]
                    },
                    slideInRight: {
                        id: "slideInRight",
                        useFirstGroupAsInitialState: !0,
                        actionItemGroups: [{
                            actionItems: [{
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    duration: 0,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    value: 0
                                }
                            }]
                        }, {
                            actionItems: [{
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    duration: 0,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    xValue: 100,
                                    yValue: 0,
                                    xUnit: "PX",
                                    yUnit: "PX",
                                    zUnit: "PX"
                                }
                            }]
                        }, {
                            actionItems: [{
                                actionTypeId: "STYLE_OPACITY",
                                config: {
                                    delay: 0,
                                    easing: "outQuart",
                                    duration: 1e3,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    value: 1
                                }
                            }, {
                                actionTypeId: "TRANSFORM_MOVE",
                                config: {
                                    delay: 0,
                                    easing: "outQuart",
                                    duration: 1e3,
                                    target: {
                                        id: "N/A",
                                        appliesTo: "TRIGGER_ELEMENT",
                                        useEventTarget: !0
                                    },
                                    xValue: 0,
                                    yValue: 0,
                                    xUnit: "PX",
                                    yUnit: "PX",
                                    zUnit: "PX"
                                }
                            }]
                        }]
                    }
                },
                site: {
                    mediaQueries: [{
                        key: "main",
                        min: 992,
                        max: 1e4
                    }, {
                        key: "medium",
                        min: 768,
                        max: 991
                    }, {
                        key: "small",
                        min: 480,
                        max: 767
                    }, {
                        key: "tiny",
                        min: 0,
                        max: 479
                    }]
                }
            }), "complete" === document.readyState ? e() : document.addEventListener("readystatechange", () => {
                "complete" === document.readyState && e()
            })
        }
    }
]);
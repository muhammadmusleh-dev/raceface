(() => {
    var e = {
            9078: function(e, t, r) {
                "use strict";
                var a = r(3949),
                    n = r(5134);
                a.define("tabs", e.exports = function(e) {
                    var t, r, i = {},
                        o = e.tram,
                        s = e(document),
                        l = a.env,
                        d = l.safari,
                        c = l(),
                        u = "data-w-tab",
                        f = ".w-tabs",
                        p = "w--current",
                        b = "w--tab-active",
                        h = n.triggers,
                        v = !1;

                    function w() {
                        r = c && a.env("design"), (t = s.find(f)).length && (t.each(y), a.env("preview") && !v && t.each(m), g(), a.redraw.on(i.redraw))
                    }

                    function g() {
                        a.redraw.off(i.redraw)
                    }

                    function m(t, r) {
                        var a = e.data(r, f);
                        a && (a.links && a.links.each(h.reset), a.panes && a.panes.each(h.reset))
                    }

                    function y(t, a) {
                        var n = f.substr(1) + "-" + t,
                            i = e(a),
                            o = e.data(a, f);
                        if (o || (o = e.data(a, f, {
                                el: i,
                                config: {}
                            })), o.current = null, o.tabIdentifier = n + "-" + u, o.paneIdentifier = n + "-data-w-pane", o.menu = i.children(".w-tab-menu"), o.links = o.menu.children(".w-tab-link"), o.content = i.children(".w-tab-content"), o.panes = o.content.children(".w-tab-pane"), o.el.off(f), o.links.off(f), o.menu.attr("role", "tablist"), o.links.attr("tabindex", "-1"), (l = {}).easing = (s = o).el.attr("data-easing") || "ease", d = l.intro = (d = parseInt(s.el.attr("data-duration-in"), 10)) == d ? d : 0, c = l.outro = (c = parseInt(s.el.attr("data-duration-out"), 10)) == c ? c : 0, l.immediate = !d && !c, s.config = l, !r) {
                            o.links.on("click" + f, (b = o, function(e) {
                                e.preventDefault();
                                var t = e.currentTarget.getAttribute(u);
                                t && k(b, {
                                    tab: t
                                })
                            })), o.links.on("keydown" + f, (h = o, function(e) {
                                var t, r = (t = h.current, Array.prototype.findIndex.call(h.links, e => e.getAttribute(u) === t, null)),
                                    a = e.key,
                                    n = {
                                        ArrowLeft: r - 1,
                                        ArrowUp: r - 1,
                                        ArrowRight: r + 1,
                                        ArrowDown: r + 1,
                                        End: h.links.length - 1,
                                        Home: 0
                                    };
                                if (a in n) {
                                    e.preventDefault();
                                    var i = n[a]; - 1 === i && (i = h.links.length - 1), i === h.links.length && (i = 0);
                                    var o = h.links[i].getAttribute(u);
                                    o && k(h, {
                                        tab: o
                                    })
                                }
                            }));
                            var s, l, d, c, b, h, v = o.links.filter("." + p).attr(u);
                            v && k(o, {
                                tab: v,
                                immediate: !0
                            })
                        }
                    }

                    function k(t, r) {
                        r = r || {};
                        var n, i = t.config,
                            s = i.easing,
                            l = r.tab;
                        if (l !== t.current) {
                            t.current = l, t.links.each(function(a, o) {
                                var s = e(o);
                                if (r.immediate || i.immediate) {
                                    var d = t.panes[a];
                                    o.id || (o.id = t.tabIdentifier + "-" + a), d.id || (d.id = t.paneIdentifier + "-" + a), o.href = "#" + d.id, o.setAttribute("role", "tab"), o.setAttribute("aria-controls", d.id), o.setAttribute("aria-selected", "false"), d.setAttribute("role", "tabpanel"), d.setAttribute("aria-labelledby", o.id)
                                }
                                o.getAttribute(u) === l ? (n = o, s.addClass(p).removeAttr("tabindex").attr({
                                    "aria-selected": "true"
                                }).each(h.intro)) : s.hasClass(p) && s.removeClass(p).attr({
                                    tabindex: "-1",
                                    "aria-selected": "false"
                                }).each(h.outro)
                            });
                            var c = [],
                                f = [];
                            t.panes.each(function(t, r) {
                                var a = e(r);
                                r.getAttribute(u) === l ? c.push(r) : a.hasClass(b) && f.push(r)
                            });
                            var w = e(c),
                                g = e(f);
                            if (r.immediate || i.immediate) {
                                w.addClass(b).each(h.intro), g.removeClass(b), v || a.redraw.up();
                                return
                            }
                            var m = window.scrollX,
                                y = window.scrollY;
                            n.focus(), window.scrollTo(m, y), g.length && i.outro ? (g.each(h.outro), o(g).add("opacity " + i.outro + "ms " + s, {
                                fallback: d
                            }).start({
                                opacity: 0
                            }).then(() => A(i, g, w))) : A(i, g, w)
                        }
                    }

                    function A(e, t, r) {
                        if (t.removeClass(b).css({
                                opacity: "",
                                transition: "",
                                transform: "",
                                width: "",
                                height: ""
                            }), r.addClass(b).each(h.intro), a.redraw.up(), !e.intro) return o(r).set({
                            opacity: 1
                        });
                        o(r).set({
                            opacity: 0
                        }).redraw().add("opacity " + e.intro + "ms " + e.easing, {
                            fallback: d
                        }).start({
                            opacity: 1
                        })
                    }
                    return i.ready = i.design = i.preview = w, i.redraw = function() {
                        v = !0, w(), v = !1
                    }, i.destroy = function() {
                        (t = s.find(f)).length && (t.each(m), g())
                    }, i
                })
            },
            8747: function(e, t, r) {
                r(9461), r(7624), r(286), r(8334), r(2338), r(3695), r(322), r(941), r(5134), r(3973), r(9078), r(5469)
            }
        },
        t = {};

    function r(a) {
        var n = t[a];
        if (void 0 !== n) return n.exports;
        var i = t[a] = {
            id: a,
            loaded: !1,
            exports: {}
        };
        return e[a](i, i.exports, r), i.loaded = !0, i.exports
    }
    r.m = e, r.d = (e, t) => {
        for (var a in t) r.o(t, a) && !r.o(e, a) && Object.defineProperty(e, a, {
            enumerable: !0,
            get: t[a]
        })
    }, r.hmd = e => ((e = Object.create(e)).children || (e.children = []), Object.defineProperty(e, "exports", {
        enumerable: !0,
        set: () => {
            throw Error("ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: " + e.id)
        }
    }), e), r.g = (() => {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    })(), r.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), r.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, r.nmd = e => (e.paths = [], e.children || (e.children = []), e), (() => {
        var e = [];
        r.O = (t, a, n, i) => {
            if (a) {
                i = i || 0;
                for (var o = e.length; o > 0 && e[o - 1][2] > i; o--) e[o] = e[o - 1];
                e[o] = [a, n, i];
                return
            }
            for (var s = 1 / 0, o = 0; o < e.length; o++) {
                for (var [a, n, i] = e[o], l = !0, d = 0; d < a.length; d++)(!1 & i || s >= i) && Object.keys(r.O).every(e => r.O[e](a[d])) ? a.splice(d--, 1) : (l = !1, i < s && (s = i));
                if (l) {
                    e.splice(o--, 1);
                    var c = n();
                    void 0 !== c && (t = c)
                }
            }
            return t
        }
    })(), r.rv = () => "1.3.9", (() => {
        var e = {
            246: 0
        };
        r.O.j = t => 0 === e[t];
        var t = (t, a) => {
                var n, i, [o, s, l] = a,
                    d = 0;
                if (o.some(t => 0 !== e[t])) {
                    for (n in s) r.o(s, n) && (r.m[n] = s[n]);
                    if (l) var c = l(r)
                }
                for (t && t(a); d < o.length; d++) i = o[d], r.o(e, i) && e[i] && e[i][0](), e[i] = 0;
                return r.O(c)
            },
            a = self.webpackChunk = self.webpackChunk || [];
        a.forEach(t.bind(null, 0)), a.push = t.bind(null, a.push.bind(a))
    })(), r.ruid = "bundler=rspack@1.3.9";
    var a = r.O(void 0, ["87", "442", "861"], function() {
        return r(8747)
    });
    a = r.O(a)
})();